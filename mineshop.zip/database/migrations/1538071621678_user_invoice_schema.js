'use strict'

const Schema = use('Schema')

class UserInvoiceSchema extends Schema {
  up () {
    this.create('user_invoices', (table) => {
      table.increments()
      table.integer('user_id').unsigned().notNullable().references('id').inTable('users').onUpdate('CASCADE').onDelete('CASCADE')
      table.decimal('total').unsigned().notNullable()
      table.enu('payment_method', ['MERCADOPAGO', 'PAYPAL', 'GERENCIANET', 'BANK_SLIP', 'BANK_DEPOSIT']).notNullable()
      table.enu('status', ['AWAITING_PAYMENT', 'PAYMENT_ACCEPTED', 'PAYMENT_REFUNDED', 'PAYMENT_CANCELED']).notNullable()
      table.string('ipn_token', 36).unique()
      table.string('metadata', 255)
      table.text('history')
      table.string('remote_addr', 45)
      table.text('user_agent')
      table.text('context')
      table.timestamps()
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('user_invoices')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = UserInvoiceSchema
