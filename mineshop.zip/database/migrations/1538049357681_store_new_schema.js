'use strict'

const Schema = use('Schema')
const loremIpsum = use('lorem-ipsum')
const StoreNew = use('App/Models/StoreNew')

class StoreNewsSchema extends Schema {
  up () {
    this.create('store_news', (table) => {
      table.increments()
      table.integer('store_id').unsigned().notNullable().references('id').inTable('stores').onUpdate('CASCADE').onDelete('CASCADE')
      table.string('title', 120).notNullable()
      table.text('body').notNullable()
      table.integer('views').notNullable()
      table.boolean('broadcast').notNullable()
      table.enu('status', ['PUBLISHED', 'PENDING']).notNullable()
      table.datetime('scheduled_to')
      table.timestamps()
    })

    this.schedule(async () => {
      for (let i = 0; i < 12; i++) {
        await StoreNew.create({
          store_id: 1,
          title: loremIpsum(),
          body: loremIpsum({ count: Math.floor(Math.random() * 10 * Math.random() + 1), units: 'paragraphs', format: 'html' }),
          views: Math.floor(Math.random() * 100 * Math.random() + 1),
          broadcast: false,
          status: 'PUBLISHED'
        })
      }
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('store_news')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = StoreNewsSchema
