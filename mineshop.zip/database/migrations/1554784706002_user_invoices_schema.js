'use strict'

const Schema = use('Schema')

class UserInvoicesSchema extends Schema {
  up () {
    this.table('user_invoices', (table) => {
      table.uuid('uid').notNullable().unique().after('id')
      table.decimal('subtotal').notNullable().unsigned().after('user_id')
      table.enu('payment_method', ['CREDIT_CARD', 'DEBIT_CARD', 'BANK_SLIP', 'BANK_DEPOSIT', 'GIFT_CODE', 'OTHER']).notNullable().alter()
      table.boolean('dispatched').notNullable().after('status')
      table.uuid('reference').unique().after('dispatched')
      table.dropColumn('ipn_token')
    })
  }

  down () {
    this.table('user_invoices', (table) => {})
  }
}

module.exports = UserInvoicesSchema
