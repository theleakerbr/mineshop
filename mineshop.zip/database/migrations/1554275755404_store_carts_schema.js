'use strict'

const Schema = use('Schema')

class StoreCartsSchema extends Schema {
  up () {
    this.table('store_carts', (table) => {
      table.enu('status', ['OPENED', 'AWAITING_PAYMENT', 'PAYMENT_ACCEPTED', 'PAYMENT_REFUSED', 'PAYMENT_REFUNDED', 'PAYMENT_CANCELED']).notNullable().alter()
    })
  }

  down () {
    this.table('store_carts', (table) => {
      table.enu('status', ['OPENED', 'AWAITING_PAYMENT', 'PAYMENT_ACCEPTED', 'PAYMENT_REFUNDED', 'PAYMENT_CANCELED']).notNullable().alter()
    })
  }
}

module.exports = StoreCartsSchema
