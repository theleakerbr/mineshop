'use strict'

const Schema = use('Schema')

class UserFeedbackSchema extends Schema {
  up () {
    this.create('user_feedbacks', (table) => {
      table.increments()
      table.integer('user_id').unsigned().notNullable().references('id').inTable('users').onUpdate('CASCADE').onDelete('CASCADE')
      table.string('first_name', 20)
      table.string('surname', 50)
      table.text('message')
      table.integer('note').notNullable()
      table.enu('status', ['PENDING', 'ALREADY_READ', 'PUBLISHED', 'INCONSIDERATE']).notNullable()
      table.timestamps()
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('user_feedbacks')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = UserFeedbackSchema
