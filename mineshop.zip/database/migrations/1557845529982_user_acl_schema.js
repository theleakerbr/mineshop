'use strict'

const Schema = use('Schema')

class UserAclSchema extends Schema {
  up () {
    this.table('user_acls', (table) => {
      table.integer('news').unsigned().notNullable().defaultTo(0).after('owner')
      table.integer('servers').unsigned().notNullable().defaultTo(0).after('news')
      table.integer('products').unsigned().notNullable().defaultTo(0).after('servers')
      table.integer('coupons').unsigned().notNullable().defaultTo(0).after('products')
      table.integer('operators').unsigned().notNullable().defaultTo(0).after('coupons')
      table.integer('appearance').unsigned().notNullable().defaultTo(0).after('operators')
      table.integer('settings').unsigned().notNullable().defaultTo(0).after('appearance')
      table.integer('logs').unsigned().notNullable().defaultTo(0).after('settings')
    })
  }

  down () {
    this.table('user_acls', (table) => {})
  }
}

module.exports = UserAclSchema
