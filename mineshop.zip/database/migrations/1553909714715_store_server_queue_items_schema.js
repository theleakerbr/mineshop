'use strict'

const Schema = use('Schema')

class StoreServerQueueItemsSchema extends Schema {
  up () {
    this.table('store_server_queue_items', (table) => {
      table.uuid('uuid').after('id')
      table.integer('slots_needed').after('command')
    })
  }

  down () {
    this.table('store_server_queue_items', (table) => {
      table.dropColumn('uuid')
      table.dropColumn('slots_needed')
    })
  }
}

module.exports = StoreServerQueueItemsSchema
