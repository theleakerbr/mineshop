'use strict'

const Schema = use('Schema')

class StoreSettingsSchema extends Schema {
  up () {
    this.table('store_settings', (table) => {
      table.text('discord_widget').after('scripts')
      table.text('twitter_widget').after('discord_widget')
    })
  }

  down () {
    this.table('store_settings', (table) => {})
  }
}

module.exports = StoreSettingsSchema
