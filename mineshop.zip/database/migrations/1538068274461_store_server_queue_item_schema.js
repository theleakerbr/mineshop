'use strict'

const Schema = use('Schema')

class StoreServerQueueItemSchema extends Schema {
  up () {
    this.create('store_server_queue_items', (table) => {
      table.increments()
      table.string('uuid', 36).notNullable().unique()
      table.integer('store_server_id').unsigned().notNullable().references('id').inTable('store_servers').onUpdate('CASCADE').onDelete('CASCADE')
      table.integer('store_cart_items_id').unsigned().references('id').inTable('store_cart_items').onUpdate('CASCADE').onDelete('SET NULL')
      table.string('nickname', 16).notNullable()
      table.string('command', 255).notNullable()
      table.enu('type', ['ONLINE', 'OFFLINE']).notNullable()
      table.enu('status', ['FORWARDED', 'DELIVERED', 'TIMEOUT', 'ABORTED']).notNullable()
      table.timestamps()
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('store_server_queue_items')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = StoreServerQueueItemSchema
