'use strict'

const Schema = use('Schema')

class UserSessionSchema extends Schema {
  up () {
    this.create('user_sessions', (table) => {
      table.increments()
      table.integer('user_id').unsigned().notNullable().references('id').inTable('users').onUpdate('CASCADE').onDelete('CASCADE')
      table.string('token', 36).unique().notNullable()
      table.boolean('active').notNullable()
      table.string('remote_addr', 45)
      table.text('user_agent')
      table.timestamps()
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('user_sessions')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = UserSessionSchema
