'use strict'

const Schema = use('Schema')

class UserInvoicesSchema extends Schema {
  up () {
    this.table('user_invoices', (table) => {
      table.enu('payment_method', ['CREDIT_CARD', 'DEBIT_CARD', 'PICPAY', 'BANK_SLIP', 'BANK_DEPOSIT', 'GIFT_CODE', 'OTHER']).notNullable().alter()
    })
  }

  down () {
    this.table('user_invoices', (table) => {})
  }
}

module.exports = UserInvoicesSchema
