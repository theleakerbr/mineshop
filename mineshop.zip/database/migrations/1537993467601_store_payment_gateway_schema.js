'use strict'

const Schema = use('Schema')
const StorePaymentGateway = use('App/Models/StorePaymentGateway')

class StorePaymentGatewaySchema extends Schema {
  up () {
    this.create('store_payment_gateways', (table) => {
      table.increments()
      table.integer('store_id').unsigned().notNullable().references('id').inTable('stores').onUpdate('CASCADE').onDelete('CASCADE')
      table.text('paypal')
      table.text('mercadopago')
      table.text('pagseguro')
      table.timestamps()
    })

    this.schedule(async () => {
      await StorePaymentGateway.create({
        store_id: 1,
        paypal: null,
        mercadopago: null,
        pagseguro: null
      })
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('store_payment_gateways')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = StorePaymentGatewaySchema
