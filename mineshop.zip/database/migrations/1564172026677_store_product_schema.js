'use strict'

const Schema = use('Schema')

class StoreProductSchema extends Schema {
  up () {
    this.table('store_products', (table) => {
      table.dropColumn('commands')
    })
  }

  down () {
    this.table('store_products', (table) => {})
  }
}

module.exports = StoreProductSchema
