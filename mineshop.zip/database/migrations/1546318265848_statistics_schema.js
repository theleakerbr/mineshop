'use strict'

const Schema = use('Schema')
const Statistic = use('App/Models/Statistic')

class StatisticsSchema extends Schema {
  up () {
    this.create('statistics', (table) => {
      table.string('key', 30).primary().notNullable()
      table.text('value')
      table.timestamps()
    })

    this.schedule(async () => {
      await Statistic.create({
        key: 'instancedStores',
        value: 0
      })

      await Statistic.create({
        key: 'approvedPayments',
        value: 0
      })
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('statistics')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = StatisticsSchema
