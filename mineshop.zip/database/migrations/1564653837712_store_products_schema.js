'use strict'

const Schema = use('Schema')

class StoreProductsSchema extends Schema {
  up () {
    this.table('store_products', (table) => {
      table.integer('min').unsigned().after('price')
      table.integer('max').unsigned().after('min')
    })
  }

  down () {
    this.table('store_products', (table) => {
      table.dropColumn('min')
      table.dropColumn('max')
    })
  }
}

module.exports = StoreProductsSchema
