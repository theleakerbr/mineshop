'use strict'

const Schema = use('Schema')
const StoreDiscountCoupon = use('App/Models/StoreDiscountCoupon')

class StoreDiscountCouponSchema extends Schema {
  up () {
    this.create('store_discount_coupons', (table) => {
      table.increments()
      table.integer('store_id').unsigned().notNullable().references('id').inTable('stores').onUpdate('CASCADE').onDelete('CASCADE')
      table.string('code', 20).notNullable()
      table.integer('discount').unsigned().notNullable()
      table.timestamps()
    })

    this.schedule(async () => {
      await StoreDiscountCoupon.create({
        store_id: 1,
        code: '10OFF',
        discount: 10
      })

      await StoreDiscountCoupon.create({
        store_id: 1,
        code: '50OFF',
        discount: 50
      })

      await StoreDiscountCoupon.create({
        store_id: 1,
        code: '100OFF',
        discount: 100
      })
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('store_discount_coupons')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = StoreDiscountCouponSchema
