'use strict'

const Schema = use('Schema')
const StoreProduct = use('App/Models/StoreProduct')

class StoreProductSchema extends Schema {
  up () {
    this.create('store_products', (table) => {
      table.increments()
      table.integer('store_id').unsigned().notNullable().references('id').inTable('stores').onUpdate('CASCADE').onDelete('CASCADE')
      table.integer('store_server_id').unsigned().references('id').inTable('store_servers').onUpdate('CASCADE').onDelete('SET NULL')
      table.string('name', 30).notNullable()
      table.string('image', 255)
      table.text('description')
      table.decimal('price').unsigned().notNullable()
      table.text('commands').notNullable()
      table.string('buy_label', 30)
      table.integer('position').unsigned().notNullable()
      table.boolean('available').notNullable()
      table.timestamps()
    })

    this.schedule(async () => {
      await StoreProduct.create({
        store_id: 1,
        store_server_id: 1,
        name: 'VIP Diamante',
        image: '/official/img/exemplo-vipdiamante.png',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla malesuada in velit eu molestie. Quisque diam risus, porta eget velit sed, fringilla congue nunc.',
        price: 29.90,
        commands: JSON.stringify({ paymentAccepted: [], chargeback: [] }),
        buy_label: null,
        position: 3,
        available: 1
      })

      await StoreProduct.create({
        store_id: 1,
        store_server_id: 1,
        name: 'VIP Ouro',
        image: '/official/img/exemplo-vipouro.png',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla malesuada in velit eu molestie. Quisque diam risus, porta eget velit sed, fringilla congue nunc.',
        price: 19.90,
        commands: JSON.stringify({ paymentAccepted: [], chargeback: [] }),
        buy_label: null,
        position: 4,
        available: 1
      })

      await StoreProduct.create({
        store_id: 1,
        store_server_id: 1,
        name: 'VIP Ferro',
        image: '/official/img/exemplo-vipferro.png',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla malesuada in velit eu molestie. Quisque diam risus, porta eget velit sed, fringilla congue nunc.',
        price: 9.90,
        commands: JSON.stringify({ paymentAccepted: [], chargeback: [] }),
        buy_label: null,
        position: 5,
        available: 1
      })

      await StoreProduct.create({
        store_id: 1,
        store_server_id: 2,
        name: 'Castelo do clan',
        image: '/official/img/exemplo-castelo.png',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla malesuada in velit eu molestie. Quisque diam risus, porta eget velit sed, fringilla congue nunc.',
        price: 4.90,
        commands: JSON.stringify({ paymentAccepted: [], chargeback: [] }),
        buy_label: null,
        position: 1,
        available: 1
      })

      await StoreProduct.create({
        store_id: 1,
        store_server_id: 2,
        name: '1k de gemas',
        image: '/official/img/exemplo-gemas.png',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla malesuada in velit eu molestie. Quisque diam risus, porta eget velit sed, fringilla congue nunc.',
        price: 10.00,
        commands: JSON.stringify({ paymentAccepted: [], chargeback: [] }),
        buy_label: null,
        position: 2,
        available: 1
      })
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('store_products')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = StoreProductSchema
