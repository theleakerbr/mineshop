'use strict'

const Schema = use('Schema')

class UserAclSchema extends Schema {
  up () {
    this.create('user_acls', (table) => {
      table.increments()
      table.integer('user_id').unsigned().notNullable().references('id').inTable('users').onUpdate('CASCADE').onDelete('CASCADE')
      table.integer('store_id').unsigned().notNullable().references('id').inTable('stores').onUpdate('CASCADE').onDelete('CASCADE')
      table.integer('owner').unsigned().notNullable()
      table.integer('license').unsigned().notNullable().defaultTo(0)
      table.timestamps()
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('user_acls')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = UserAclSchema
