'use strict'

const Schema = use('Schema')
const StoreServer = use('App/Models/StoreServer')
const uuid = use('uuid')

class StoreServerSchema extends Schema {
  up () {
    this.create('store_servers', (table) => {
      table.increments()
      table.integer('store_id').unsigned().notNullable().references('id').inTable('stores').onUpdate('CASCADE').onDelete('CASCADE')
      table.string('token', 36).unique().notNullable()
      table.string('name', 15).notNullable()
      table.datetime('last_connection')
      table.timestamps()
    })

    this.schedule(async () => {
      await StoreServer.create({
        store_id: 1,
        token: uuid.v4(),
        name: 'Survival',
        last_connection: null
      })

      await StoreServer.create({
        store_id: 1,
        token: uuid.v4(),
        name: 'Factions',
        last_connection: null
      })

      await StoreServer.create({
        store_id: 1,
        token: uuid.v4(),
        name: 'Full PvP',
        last_connection: null
      })
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('store_servers')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = StoreServerSchema
