'use strict'

const Schema = use('Schema')

class StoreCartSchema extends Schema {
  up () {
    this.create('store_carts', (table) => {
      table.increments()
      table.integer('store_id').unsigned().notNullable().references('id').inTable('stores').onUpdate('CASCADE').onDelete('CASCADE')
      table.string('nickname', 16)
      table.string('email', 254)
      table.string('crafatar_uuid', 36)
      table.string('coupon_code', 20)
      table.integer('coupon_discount').unsigned()
      table.decimal('subtotal').unsigned()
      table.decimal('total').unsigned()
      table.enu('payment_method', ['PAGSEGURO', 'MERCADOPAGO', 'PAYPAL', 'OTHER'])
      table.enu('status', ['OPENED', 'AWAITING_PAYMENT', 'PAYMENT_ACCEPTED', 'PAYMENT_REFUNDED', 'PAYMENT_CANCELED']).notNullable()
      table.boolean('dispatched').notNullable()
      table.string('ipn_token', 36).unique()
      table.string('remote_addr', 45)
      table.text('user_agent')
      table.text('context')
      table.timestamps()
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('store_carts')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = StoreCartSchema
