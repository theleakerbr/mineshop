'use strict'

const Schema = use('Schema')
const _ = use('lodash')

const StoreProduct = use('App/Models/StoreProduct')
const StoreProductCommand = use('App/Models/StoreProductCommand')

class StoreProductCommandsSchema extends Schema {
  up () {
    this.schedule(async () => {
      const products = (await StoreProduct.all()).toJSON()
      _.forEach(products, (product) => {
        const commands = JSON.parse(product.commands)
        _.forEach(commands.paymentAccepted, async (command) => {
          await StoreProductCommand.create({
            store_product_id: product.id,
            command: command.cmd,
            slots: command.slots || 0,
            offline_delivery: command.type === 'OFFLINE',
            trigger: 'PAYMENT_ACCEPTED'
          })
        })
      })
    })
  }

  down () {
    this.table('store_product_commands', (table) => {})
  }
}

module.exports = StoreProductCommandsSchema
