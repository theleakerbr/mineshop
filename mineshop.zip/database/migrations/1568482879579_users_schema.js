'use strict'

/** @type {import('@adonisjs/lucid/src/Schema')} */
const Schema = use('Schema')

class UsersSchema extends Schema {
  up () {
    this.table('users', (table) => {
      table.string('discord_tag', 32).after('phone')
      table.dropColumn('skype')
    })
  }

  down () {
    this.table('users', (table) => {
      table.string('skype', 255).after('phone')
      table.dropColumn('discord_tag')
    })
  }
}

module.exports = UsersSchema
