'use strict'

const Schema = use('Schema')

class StoreProductCommandSchema extends Schema {
  up () {
    this.create('store_product_commands', (table) => {
      table.increments()
      table.integer('store_product_id').unsigned().references('id').inTable('store_products').onUpdate('CASCADE').onDelete('CASCADE')
      table.string('command', 255).notNullable()
      table.integer('slots').unsigned().notNullable()
      table.boolean('offline_delivery').notNullable()
      table.enu('trigger', ['PAYMENT_ACCEPTED', 'CHARGEBACK']).notNullable()
      table.timestamps()
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('store_product_commands')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = StoreProductCommandSchema
