'use strict'

const Schema = use('Schema')
const StoreSetting = use('App/Models/StoreSetting')

class StoreSettingSchema extends Schema {
  up () {
    this.create('store_settings', (table) => {
      table.increments()
      table.integer('store_id').unsigned().notNullable().references('id').inTable('stores').onUpdate('CASCADE').onDelete('CASCADE')
      table.string('name', 20).notNullable()
      table.string('slogan', 50)
      table.string('favicon', 255)
      table.string('logotipo', 255)
      table.string('analytics', 20)
      table.text('sliders')
      table.text('terms')
      table.text('refund_policy')
      table.text('colors')
      table.text('styles')
      table.text('scripts')
      table.enu('template', ['DEFAULT', 'CUSTOM']).notNullable()
      table.timestamps()
    })

    this.schedule(async () => {
      await StoreSetting.create({
        store_id: 1,
        name: 'Loja exemplo',
        slogan: 'jogar.exemplo.com.br',
        favicon: null,
        logotipo: null,
        analytics: null,
        sliders: JSON.stringify(['/official/img/firstslider.png', '/official/img/firstslider.png', '/official/img/firstslider.png']),
        terms: 'Essa é a área de termos de uso. Dentro do painel você pode alterar o que é exibido aqui ou pode desabilitar esse link, caso ache que não precisa disso.',
        refund_policy: 'Essa é a área onde fica a política de reembolso do seu servidor. Se você criar uma boa política de reembolso, você venderá mais porque seus clientes se sentirão seguros. Além disso, isso pode te ajudar tomar menos chargebacks. Caso queira, você também pode desabilitar esse link no seu painel de controle.',
        colors: null,
        styles: null,
        scripts: null,
        template: 'DEFAULT'
      })
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('store_settings')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = StoreSettingSchema
