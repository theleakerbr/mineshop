'use strict'

const Schema = use('Schema')

class StoreSettingsSchema extends Schema {
  up () {
    this.table('store_settings', (table) => {
      table.enu('template', ['DEFAULT', 'CLASSIC', 'CUSTOM']).notNullable().alter()
    })
  }

  down () {
    this.table('store_settings', (table) => {})
  }
}

module.exports = StoreSettingsSchema
