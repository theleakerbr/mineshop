'use strict'

const Schema = use('Schema')

class StoreServerQueueItemsSchema extends Schema {
  up () {
    this.table('store_server_queue_items', (table) => {
      table.dropColumn('uuid')
    })
  }

  down () {
    this.table('store_server_queue_items', (table) => {
      table.string('uuid', 36).after('id')
    })
  }
}

module.exports = StoreServerQueueItemsSchema
