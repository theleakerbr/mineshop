'use strict'

const Schema = use('Schema')

class StoreCartItemSchema extends Schema {
  up () {
    this.create('store_cart_items', (table) => {
      table.increments()
      table.integer('store_cart_id').unsigned().notNullable().references('id').inTable('store_carts').onUpdate('CASCADE').onDelete('CASCADE')
      table.integer('store_product_id').unsigned().references('id').inTable('store_products').onUpdate('CASCADE').onDelete('SET NULL')
      table.integer('quantity').unsigned().notNullable()
      table.timestamps()
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('store_cart_items')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = StoreCartItemSchema
