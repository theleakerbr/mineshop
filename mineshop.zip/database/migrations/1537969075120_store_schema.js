'use strict'

const Schema = use('Schema')
const Store = use('App/Models/Store')

class StoreSchema extends Schema {
  up () {
    this.create('stores', (table) => {
      table.increments()
      table.string('address', 255).unique().notNullable()
      table.integer('days_remaining').notNullable()
      table.enu('plan', ['SANDBOX', 'PROFISSIONAL']).notNullable()
      table.enu('status', ['ACTIVE', 'SUSPENDED', 'PENDING']).notNullable()
      table.decimal('custom_price').unsigned()
      table.timestamps()
    })

    this.schedule(async () => {
      await Store.create({
        address: 'exemplo.mineshop.com.br',
        days_remaining: 0,
        plan: 'SANDBOX',
        status: 'ACTIVE',
        custom_price: null
      })
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('stores')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = StoreSchema
