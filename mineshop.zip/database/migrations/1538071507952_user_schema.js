'use strict'

const Schema = use('Schema')

class UserSchema extends Schema {
  up () {
    this.create('users', (table) => {
      table.increments()
      table.string('email', 254).unique().notNullable()
      table.string('password', 255).notNullable()
      table.enu('group', ['ADMIN', 'CLIENT', 'BANNED']).notNullable()
      table.integer('manage_store')
      table.string('first_name', 15)
      table.string('surname', 50)
      table.string('phone', 11)
      table.string('skype', 255)
      table.boolean('is_verified').notNullable()
      table.string('tfa', 32).unique()
      table.integer('referral')
      table.string('remote_addr', 45)
      table.text('user_agent')
      table.timestamps()
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('users')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = UserSchema
