'use strict'

const Schema = use('Schema')

class StoreLogSchema extends Schema {
  up () {
    this.create('store_logs', (table) => {
      table.increments()
      table.integer('store_id').unsigned().notNullable().references('id').inTable('stores').onUpdate('CASCADE').onDelete('CASCADE')
      table.text('message').notNullable()
      table.string('remote_addr', 45)
      table.text('user_agent')
      table.timestamps()
    })
  }

  down () {
    this.raw('SET FOREIGN_KEY_CHECKS = 0')
    this.drop('store_logs')
    this.raw('SET FOREIGN_KEY_CHECKS = 1')
  }
}

module.exports = StoreLogSchema
