'use strict'

const _ = use('lodash')

class Utils {
  validators () {
    return {
      cpf: (cpf) => {
        if (!_.isString(cpf)) {
          return false
        }

        cpf = _.replace(cpf, /[^0-9]/g, '')

        if (cpf.length !== 11 || cpf.match(/(\d)\1{10}/)) {
          return false
        }

        const cpfSplited = _.reverse(_.split(cpf, ''))
        const digits = { first: null, second: null }

        while (true) {
          let sum = _.isNull(digits.first) ? 0 : digits.first * 2
          const add = _.isNull(digits.first) ? 0 : 1

          _.forEach(cpfSplited, (value, key) => {
            if (key >= 2) {
              sum = (value * (key + add)) + sum
            }
          })

          const module = sum % 11

          if (!_.isNull(digits.first)) {
            digits.second = module < 2 ? 0 : 11 - module
            break
          }

          digits.first = module < 2 ? 0 : 11 - module
        }

        return digits.first === parseInt(cpfSplited[1]) && digits.second === parseInt(cpfSplited[0]);
      }
    }
  }
}

module.exports = Utils
