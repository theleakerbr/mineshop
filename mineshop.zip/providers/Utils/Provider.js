'use strict'

const { ServiceProvider } = require('@adonisjs/fold')

class UtilsProvider extends ServiceProvider {
  register () {
    this.app.singleton('Utils', () => {
      return new (require('.'))()
    })
  }
}

module.exports = UtilsProvider
