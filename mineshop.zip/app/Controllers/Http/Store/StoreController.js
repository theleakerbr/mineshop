'use strict'

const { validateAll, sanitize, rule } = use('Validator')

const _ = use('lodash')
const querystring = use('querystring')
const numberFormat = use('locutus/php/strings/number_format')
const xml2js = use('xml2js')
const uuid = use('uuid')
const Env = use('Env')
const Helpers = use('Helpers')
const exec = Helpers.promisify(use('child_process').exec)
const axios = use('axios')
const Route = use('Route')

const StoreCart = use('App/Models/StoreCart')
const StoreServer = use('App/Models/StoreServer')
const StoreProduct = use('App/Models/StoreProduct')
const StoreNew = use('App/Models/StoreNew')
const StoreCartItem = use('App/Models/StoreCartItem')
const StoreDiscountCoupon = use('App/Models/StoreDiscountCoupon')
const StorePaymentGateway = use('App/Models/StorePaymentGateway')

class StoreController {
  async products ({ request, view, subdomains }) {
    let servers = await StoreServer
    .query()
    .where('store_id', request.store.id)
    .orderBy('name', 'asc')
    .fetch()

    servers = servers.toJSON()

    let products = await StoreProduct
    .query()
    .where('store_id', request.store.id)
    .andWhere('store_server_id', '>', 0)
    .andWhere('available', true)
    .orderBy('position', 'asc')
    .fetch()

    products = products.toJSON()

    try {
      return view.render(request.store.template.index, {
        servers: servers,
        products: products
      })
    } catch (err) {
      const tmp = request.store.template.index.split('.')
      throw new Error(
        `Problema no template: ${tmp[1]} ${tmp[3] || tmp[2]}`.replace(/\s+/g, ' ')
      )
    }
  }

  async cart ({ request, response, view }) {
    let paymentGateways = await StorePaymentGateway
    .query()
    .where('store_id', request.store.id)
    .first()

    try {
      paymentGateways = paymentGateways.toJSON()
    } catch (err) {}

    try {
      return view.render(request.store.template.cart, {
        paymentGateways: {
          paypal: _.has(paymentGateways, 'paypal.basic.active')
          ? paymentGateways.paypal.basic.active
          : false,

          mercadopago: _.has(paymentGateways, 'mercadopago.basic.active')
          ? paymentGateways.mercadopago.basic.active
          : false,

          pagseguro: _.has(paymentGateways, 'pagseguro.basic.active')
          ? paymentGateways.pagseguro.basic.active
          : false
        }
      })
    } catch (err) {
      const tmp = request.store.template.cart.split('.')
      throw new Error(
        `Problema no template: ${tmp[1]} ${tmp[3] || tmp[2]}`.replace(/\s+/g, ' ')
      )
    }
  }

  async news ({ request, response, params, view, session }) {
    const id = params.id || false

    if (id) {
      let news = await StoreNew
      .query()
      .setHidden(['store_id'])
      .where('store_id', request.store.id)
      .andWhere('id', id)
      .andWhere('status', 'PUBLISHED')
      .first()

      if (news) {
        const newsAlreadyRead = session.get('newsAlreadyRead', [])

        if (!newsAlreadyRead[id]) {
          newsAlreadyRead[id] = true
          session.put('newsAlreadyRead', newsAlreadyRead)

          news.merge({
            views: news.views + 1
          })

          await news.save()
        }

        news = news.toJSON()

        try {
          return view.render(request.store.template.news, {
            news: news
          })
        } catch (err) {
          const tmp = request.store.template.news.split('.')
          throw new Error(
            `Problema no template: ${tmp[1]} ${tmp[3] || tmp[2]}`.replace(/\s+/g, ' ')
          )
        }
      } else {
        response.redirect(Route.url('store.news'))
      }
    } else {
      const page = request.get().page >= 1 ? parseInt(request.get().page, 10) : 1
      const limit = 5

      let allNews = await StoreNew
      .query()
      .setHidden(['store_id'])
      .where('store_id', request.store.id)
      .andWhere('status', 'PUBLISHED')
      .orderBy('created_at', 'desc')
      .paginate(page, limit)

      allNews = allNews ? allNews.toJSON() : allNews
      const pages = []

      for (let i = 0; i < allNews.lastPage; i++) {
        pages.push(i + 1)
      }

      try {
        return view.render(request.store.template.allNews, {
          allNews: allNews,
          pages: pages
        })
      } catch (err) {
        const tmp = request.store.template.allNews.split('.')
        throw new Error(
          `Problema no template: ${tmp[1]} ${tmp[3] || tmp[2]}`.replace(/\s+/g, ' ')
        )
      }
    }
  }

  async orders ({ request, response, view }) {
    const cookieOrders = JSON.parse(request.cookie('orders', '[]'))
    const orders = []

    if (cookieOrders.length > 10) {
      cookieOrders.shift();
    }

    for (let i = 0; i < cookieOrders.length; i++) {
      let order = await StoreCart
      .query()
      .setVisible(['nickname', 'coupon_code', 'coupon_discount', 'subtotal', 'total', 'payment_method', 'status'])
      .where('store_id', request.store.id)
      .andWhere('id', cookieOrders[i])
      .first()

      order = order ? order.toJSON() : order

      if (order) {
        orders.push(order)
      } else {
        delete cookieOrders[i]
      }
    }

    for (let order in orders) {
      orders[order].status = orders[order].status
      .replace('OPENED', 'Aberto')
      .replace('AWAITING_PAYMENT', 'Aguardando pagamento')
      .replace('PAYMENT_ACCEPTED', 'Pagamento aprovado')
      .replace('PAYMENT_REFUNDED', 'Reembolsado')
      .replace('PAYMENT_CANCELED', 'Cancelado')
    }

    orders.reverse()

    response.cookie('orders', JSON.stringify(cookieOrders), {
      path: '/',
      httpOnly: true,
      maxAge: 7776000,
    })

    try {
      return view.render(request.store.template.orders, {
        orders: orders
      })
    } catch (err) {
      const tmp = request.store.template.orders.split('.')
      throw new Error(
        `Problema no template: ${tmp[1]} ${tmp[3] || tmp[2]}`.replace(/\s+/g, ' ')
      )
    }
  }

  async apiGetCart ({ request }) {
    const cart = JSON.parse(JSON.stringify(request.store.cart))
    delete cart.id
    return cart
  }

  async apiUpdatePlayer ({ request, response }) {
    const sanitizeRules = {
      nickname: 'trim',
      email: 'trim|normalize_email'
    }

    const rules = {
      email: 'required|email',
      nickname: [
        rule('required'),
        rule('min', 3),
        rule('max', 16),
        rule('regex', /^\S*$/)
      ]
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'email': 'O endereço de email informado é inválido.',
      'min': 'Esse campo precisa ter no mínimo {{ argument.0 }} caracteres.',
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres.',
      'regex': 'Esse campo não pode ter espaços.'
    }

    const params = sanitize(request.only(['nickname', 'email']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      let mojangUuid = '12ccd852-6599-34ed-a0db-c0d932428b4c'

      try {
        const res = await axios.get(`https://api.mojang.com/users/profiles/minecraft/${params.nickname}`)
        if (typeof res.data.id !== 'undefined') {
          mojangUuid = res.data.id
        }
      } catch (err) {}

      const cart = await StoreCart.find(request.store.cart.id)

      cart.merge({
        nickname: params.nickname,
        email: params.email,
        crafatar_uuid: mojangUuid
      })

      await cart.save()

      return {
        nickname: params.nickname,
        email: params.email,
        crafatar_uuid: mojangUuid
      }
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async apiUpdateCoupon ({ request, response }) {
    const sanitizeRules = {
      coupon: 'trim'
    }

    const rules = {
      coupon: [
        rule('max', 20),
        rule('regex', /^\S*$/)
      ]
    }

    const messages = {
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres',
      'regex': 'Esse campo não pode ter espaços'
    }

    const params = sanitize(request.only(['coupon']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      if (params.coupon) {
        let coupon = await StoreDiscountCoupon
        .query()
        .where('store_id', request.store.id)
        .andWhere('code', params.coupon)
        .first()

        coupon = coupon ? coupon.toJSON() : false

        if (coupon) {
          const cart = await StoreCart.find(request.store.cart.id)
          if (cart) {
            cart.merge({
              coupon_code: coupon.code,
              coupon_discount: coupon.discount
            })

            await cart.save()
          }
        }
      }

      response.status(204)
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async apiUpdateItem ({ request, response }) {
    const sanitizeRules = {
      id: 'to_int',
      rewriteQuantity: 'to_boolean',
      quantity: 'to_int'
    }

    const rules = {
      id: 'required|min:1',
      rewriteQuantity: 'required',
      quantity: 'required|min:-1'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'min': 'O valor desse campo deve ser no de mínimo {{ argument.0 }}.',
      'max': 'O valor desse campo deve ser no de máximo {{ argument.0 }}.',
    }

    const params = sanitize(request.only(['id', 'rewriteQuantity', 'quantity']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      const product = await StoreProduct
      .query()
      .where('store_id', request.store.id)
      .andWhere('id', params.id)
      .first()

      if (product) {
        let storeCartItem = await StoreCartItem
        .query()
        .where('store_cart_id', request.store.cart.id)
        .andWhere('store_product_id', params.id)
        .first()

        if (!storeCartItem) {
          storeCartItem = new StoreCartItem()
        }

        storeCartItem.merge({
          store_cart_id: storeCartItem.store_cart_id || request.store.cart.id,
          store_product_id: storeCartItem.store_product_id || params.id
        })

        if (params.rewriteQuantity) {
          storeCartItem.merge({
            quantity: params.quantity
          })
        } else {
          storeCartItem.merge({
            quantity: storeCartItem.quantity ? storeCartItem.quantity + params.quantity : params.quantity
          })
        }

        try {
          if (product.min) {
            if (storeCartItem.quantity < product.min) {
              if (params.quantity !== -1) {
                storeCartItem.quantity = product.min
              } else {
                storeCartItem.quantity = 0
              }
            }
          }

          if (product.max) {
            if (storeCartItem.quantity > product.max) {
              storeCartItem.quantity = product.max
            }
          }

          if (storeCartItem.quantity >= 1) {
            await storeCartItem.save()
          } else {
            await storeCartItem.delete()
          }
        } catch (err) {}
      }

      response.status(204)
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async apiPayment ({ request, response }) {
    if (!request.store.cart.nickname || !request.store.cart.email) {
      return response.status(422).send({
        error: { player: 'Os dados do jogador estão incompletos.' }
      })
    }

    const sanitizeRules = {
      paymentMethod: 'trim'
    }

    const rules = {
      paymentMethod: [
        rule('required'),
        rule('regex', /^PAGSEGURO$|^MERCADOPAGO$|^PAYPAL$/)
      ]
    }

    const messages = {
      'required': 'Uma variável paymentMethod deve ser passada como parâmetro.',
      'regex': 'O valor passado em paymentMethod é inválido.'
    }

    const params = sanitize(request.only(['paymentMethod']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      if (request.store.plan === 'SANDBOX') {
        return response.status(422).send({
          error: { plan: 'Operação não permitida porque esta loja está em modo sandbox.' }
        })
      }

      const cart = await StoreCart.find(request.store.cart.id)

      cart.merge({
        subtotal: request.store.cart.subtotal,
        total: request.store.cart.total,
        payment_method: request.store.cart.total === 0 ? 'OTHER' : params.paymentMethod,
        status: request.store.cart.total === 0 ? 'PAYMENT_ACCEPTED' : 'AWAITING_PAYMENT',
        ipn_token: uuid.v4()
      })

      await cart.save()

      const cookieOrders = JSON.parse(request.cookie('orders', '[]'))
      cookieOrders.push(cart.$attributes.id)

      response.cookie('orders', JSON.stringify(cookieOrders), {
        path: '/',
        httpOnly: true,
        maxAge: 7776000,
      })

      if (request.store.cart.total === 0) {
        return {
          paymentUrl: `https://${request.store.address}${Route.url('store.orders')}`
        }
      }

      let paymentGateways = await StorePaymentGateway
      .query()
      .where('store_id', request.store.id)
      .first()

      paymentGateways = _.isFunction(paymentGateways.toJSON)
      ? paymentGateways.toJSON()
      : paymentGateways

      if (params.paymentMethod === 'PAGSEGURO') {
        if (!_.has(paymentGateways, 'pagseguro.basic.active') || !paymentGateways.pagseguro.basic.active) {
          return response.status(422).send({
            error: { paymentMethod: 'Este método de pagamento não está habilitado nesta loja.' }
          })
        }

        const url = Env.get('NODE_ENV') === 'production' ? 'https://ws.pagseguro.uol.com.br/v2/checkout' : 'https://ws.sandbox.pagseguro.uol.com.br/v2/checkout'
        const authorization = `?email=${paymentGateways.pagseguro.basic.email}&token=${paymentGateways.pagseguro.basic.token}`

        let data = {
          currency: 'BRL',
          reference: cart.$attributes.ipn_token,
          senderEmail: Env.get('NODE_ENV') === 'production' ? request.store.cart.email : 'fulano@sandbox.pagseguro.com.br',
          redirectURL: `https://${request.store.address}${Route.url('store.orders')}`,
          notificationURL: `https://api.mineshop.com.br/store-ipn/v1/pagseguro/${cart.$attributes.ipn_token}`,
          extraAmount: numberFormat((cart.$attributes.total - cart.$attributes.subtotal), 2, '.', ''),
          shippingType: 1,
          shippingAddressStreet: 'Produtos virtuais nao necessitam de um endereco para entrega',
          shippingAddressNumber: 'S/N',
          shippingAddressComplement: 'por favor,',
          shippingAddressDistrict: 'ignore o CEP e Estado informados aqui.',
          shippingAddressPostalCode: '01452002',
          shippingAddressCity: 'Brasilia',
          shippingAddressState: 'DF',
          shippingAddressCountry: 'BRA',
          shippingCost: numberFormat(0, 2, '.', '')
        }

        for (let i = 0; i < request.store.cart.items.length; i++) {
          data[`itemId${i + 1}`] = request.store.cart.items[i].store_product_id
          data[`itemDescription${i + 1}`] = request.store.cart.items[i].name
          data[`itemAmount${i + 1}`] = numberFormat(request.store.cart.items[i].price, 2, '.', '')
          data[`itemQuantity${i + 1}`] = request.store.cart.items[i].quantity
        }

        data = querystring.stringify(
          data, '&', '=', {
            encodeURIComponent: (arg) => { return arg }
          }
        )

        const res = await axios.post(
          `${url}${authorization}`, data, {
            headers: {
              'Content-Type': 'application/x-www-form-urlencoded;'
            }
          }
        )

        const parseString = Helpers.promisify(xml2js.parseString)
        const jsonData = await parseString(res.data)

        return {
          paymentUrl: Env.get('NODE_ENV') === 'production'
          ? `https://pagseguro.uol.com.br/v2/checkout/payment.html?code=${jsonData.checkout.code}`
          : `https://sandbox.pagseguro.uol.com.br/v2/checkout/payment.html?code=${jsonData.checkout.code}`
        }
      }

      if (params.paymentMethod === 'MERCADOPAGO') {
        if (!_.has(paymentGateways, 'mercadopago.basic.active') || !paymentGateways.mercadopago.basic.active) {
          return response.status(422).send({
            error: { paymentMethod: 'Este método de pagamento não está habilitado nesta loja.' }
          })
        }

        const items = [
          {
            title: request.store.env.name,
            quantity: 1,
            currency_id: 'BRL',
            unit_price: 0
          }
        ]

        for (let i = 0; i < request.store.cart.items.length; i++) {
          const item = request.store.cart.items[i]

          items[i + 1] = {
            id: item.store_product_id,
            title: item.name,
            quantity: item.quantity,
            currency_id: 'BRL',
            unit_price: parseFloat(numberFormat(item.price - (item.price * (cart.$attributes.coupon_discount / 100)), 2, '.', ''))
          }
        }

        const scriptData = _.escape(JSON.stringify({
          preference: {
            items: items,
            payer: { email: request.store.cart.email },
            notification_url: `https://api.mineshop.com.br/store-ipn/v1/mercadopago/${cart.$attributes.ipn_token}`,
            auto_return: 'approved',
            external_reference: cart.$attributes.ipn_token,
            back_urls: {
              success: `https://${request.store.address}${Route.url('store.orders')}`,
              pending: `https://${request.store.address}${Route.url('store.orders')}`,
              failure: `https://${request.store.address}${Route.url('store.orders')}`
            }
          },

          credentials: {
            clientId: paymentGateways.mercadopago.basic.clientId,
            clientSecret: paymentGateways.mercadopago.basic.clientSecret
          }
        }))

        let scriptOutput = await exec(`node ${Helpers.resourcesPath('scripts/stores/mercadopago.js')} --data="${scriptData}"`)
        scriptOutput = JSON.parse(_.trim(scriptOutput))

        if (scriptOutput.success) {
          return {
            paymentUrl: Env.get('NODE_ENV') === 'production'
            ? scriptOutput.data.initPoint
            : scriptOutput.data.sandboxInitPoint
          }
        }

        //error response
        return
      }

      if (params.paymentMethod === 'PAYPAL') {
        if (!_.has(paymentGateways, 'paypal.basic.active') || !paymentGateways.paypal.basic.active) {
          return response.status(422).send({
            error: { paymentMethod: 'Este método de pagamento não está habilitado nesta loja.' }
          })
        }

        response.implicitEnd = false

        const paypal = use('paypal-rest-sdk')

        paypal.configure({
          'mode': Env.get('NODE_ENV') === 'production' ? 'live' : 'sandbox',
          'client_id': paymentGateways.paypal.basic.clientId,
          'client_secret': paymentGateways.paypal.basic.clientSecret
        })

        const paymentOptions = {
          intent: 'sale',
          payer: { payment_method: 'paypal' },
          transactions: [{ item_list: { items: [] }, amount: { currency: 'BRL', total: 0 } }],
          redirect_urls: {
            return_url: `https://api.mineshop.com.br/store-ipn/v1/paypal/${cart.$attributes.ipn_token}?storeAddr=${request.store.address}`,
            cancel_url: `https://${request.store.address}${Route.url('store.products')}`
          }
        }

        let total = 0

        for (let i = 0; i < request.store.cart.items.length; i++) {
          const item = request.store.cart.items[i]

          paymentOptions.transactions[0].item_list.items[i] = {
            name: item.name,
            sku: item.store_product_id,
            price: parseFloat(numberFormat(item.price - (item.price * (cart.$attributes.coupon_discount / 100)), 2, '.', '')),
            quantity: item.quantity,
            currency: 'BRL'
          }

          total += (paymentOptions.transactions[0].item_list.items[i].price * paymentOptions.transactions[0].item_list.items[i].quantity)
        }

        paymentOptions.transactions[0].amount.total = numberFormat(total, 2, '.', '')

        paypal.payment.create(paymentOptions, (err, payment) => {
          if (err) {
            throw new Error('Algo não saiu como esperado ao tentar obter url de pagamento do PayPal. Tente novamente!')
          }

          let paymentUrl = ''

          for (let i = 0; i < payment.links.length; i++) {
            if (payment.links[i].rel === 'approval_url') {
              paymentUrl = payment.links[i].href
              break
            }
          }

          return response.status(200).send({ paymentUrl: paymentUrl })
        })
      }
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }
}

module.exports = StoreController
