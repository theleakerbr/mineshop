'use strict'

const _ = use('lodash')
const axios = use('axios')
const Helpers = use('Helpers')
const exec = Helpers.promisify(use('child_process').exec)
const Env = use('Env')
const Route = use('Route')
const xml2js = use('xml2js')

const StoreCart = use('App/Models/StoreCart')

class PaymentNotificationController {
  async pagseguro ({ request, response }) {
    const { notificationCode } = request.all()
    const credentials = request.gateways.pagseguro

    if (!credentials.basic.email || !credentials.basic.token) {
      return response.status(422).send({
        message: 'bad gateway credentials'
      })
    }

    const res = await axios.get(`https://ws.pagseguro.uol.com.br/v3/transactions/notifications/${notificationCode}?email=${credentials.basic.email}&token=${credentials.basic.token}`)
    const parseString = Helpers.promisify(xml2js.parseString)
    const jsonData = await parseString(res.data)

    const paymentStatusCode = _.toInteger(jsonData.transaction.status)
    let paymentStatus = false

    paymentStatus = _.isEqual(paymentStatusCode, 1) || _.isEqual(paymentStatusCode, 2)
    ? 'AWAITING_PAYMENT'
    : paymentStatus

    paymentStatus = _.isEqual(paymentStatusCode, 3) || _.isEqual(paymentStatusCode, 4)
    ? 'PAYMENT_ACCEPTED'
    : paymentStatus

    paymentStatus = _.isEqual(paymentStatusCode, 6) || _.isEqual(paymentStatusCode, 8)
    ? 'PAYMENT_REFUNDED'
    : paymentStatus

    paymentStatus = _.isEqual(paymentStatusCode, 7)
    ? 'PAYMENT_CANCELED'
    : paymentStatus

    if (!paymentStatus) {
      return response.status(422).send()
    }

    const cart = await StoreCart.find(request.cart.id)

    cart.merge({
      status: paymentStatus,
      context: JSON.stringify(jsonData, null, 2)
    })

    await cart.save()
    response.status(200).send()
  }

  async paypal ({ request, response }) {
    const { paymentId, token, storeAddr } = request.all()
    const payerId = request.all()['PayerID']
    const credentials = request.gateways.paypal

    response.implicitEnd = false

    const paypal = use('paypal-rest-sdk')

    paypal.configure({
      'mode': Env.get('NODE_ENV') === 'production' ? 'live' : 'sandbox',
      'client_id': credentials.basic.clientId,
      'client_secret': credentials.basic.clientSecret
    })

    paypal.payment.execute(paymentId, { payer_id: payerId }, async (err, payment) => {
      if (err) {
        console.error(err.message)
      } else if (_.isEqual(payment.state, 'approved')) {
        const cart = await StoreCart.find(request.cart.id)

        cart.merge({
          status: 'PAYMENT_ACCEPTED',
          context: JSON.stringify(payment, null, 2)
        })

        await cart.save()
      }

      response.redirect(`https://${storeAddr}${Route.url('store.orders')}`)
    })
  }

  async mercadopago ({ request, response }) {
    const credentials = request.gateways.mercadopago
    const params = request.all()

    if (_.isUndefined(params.type) || !_.has(params, 'data.id') || params.type !== 'payment') {
      return response.status(422).send()
    }

    const scriptData = _.escape(JSON.stringify({
      credentials: {
        clientId: credentials.basic.clientId,
        clientSecret: credentials.basic.clientSecret
      }
    }))

    let scriptOutput = await exec(`node ${Helpers.resourcesPath('scripts/stores/mp-access-token.js')} --data="${scriptData}"`)
    scriptOutput = JSON.parse(_.trim(scriptOutput))

    if (!scriptOutput.success) {
      return response.status(422).send()
    }

    const res = await axios.get(`https://api.mercadopago.com/v1/payments/${params.data.id}?access_token=${scriptOutput.data.accessToken}`)
    const payment = res.data

    if (!_.isUndefined(payment.status)) {
      let paymentStatus = false

      paymentStatus = _.isEqual(payment.status, 'in_process')
      ? 'AWAITING_PAYMENT'
      : paymentStatus

      paymentStatus = _.isEqual(payment.status, 'approved')
      ? 'PAYMENT_ACCEPTED'
      : paymentStatus

      paymentStatus = _.isEqual(payment.status, 'rejected')
      ? 'PAYMENT_CANCELED'
      : paymentStatus

      if (!paymentStatus) {
        return response.status(422).send()
      }

      const cart = await StoreCart.find(request.cart.id)

      cart.merge({
        status: paymentStatus,
        context: JSON.stringify(payment, null, 2)
      })

      await cart.save()
      response.status(200).send()
    }
  }
}

module.exports = PaymentNotificationController
