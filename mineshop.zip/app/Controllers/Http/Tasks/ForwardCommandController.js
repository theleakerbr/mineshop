'use strict'

const Logger = use('Logger')
const Database = use('Database')
const uuid = use('uuid')

const StoreCart = use('App/Models/StoreCart')
const StoreCartItem = use('App/Models/StoreCartItem')
const StoreProduct = use('App/Models/StoreProduct')
const StoreProductCommand = use('App/Models/StoreProductCommand')
const StoreServerQueueItem = use('App/Models/StoreServerQueueItem')

class ForwardCommandController {
  async create () {
    const carts = await this.getPaidCarts()

    for (let cart in carts) {
      carts[cart].items = await this.getCartItems(carts[cart].id)
      for (let item in carts[cart].items) {
        carts[cart].items[item].store_server_id = await this.getProductServerId(carts[cart].items[item].store_product_id)
        carts[cart].items[item].commands = await this.getProductCommands(carts[cart].items[item].store_product_id)
      }

      const trx = await Database.beginTransaction()

      try {
        const updateCart = await StoreCart.find(carts[cart].id)

        updateCart.merge({
          dispatched: true
        })

        await updateCart.save(trx)

        for (let item in carts[cart].items) {
          for (let command in carts[cart].items[item].commands) {
            const re = new RegExp('%amount%|%quantity%|%quantidade%', 'gi')
            if (re.test(carts[cart].items[item].commands[command].command)) {
              await StoreServerQueueItem.create({
                uuid: uuid.v4(),
                store_server_id: carts[cart].items[item].store_server_id,
                store_cart_items_id: carts[cart].items[item].id,
                nickname: carts[cart].nickname,
                command: carts[cart].items[item].commands[command].command.replace(/%nickname%|%player%|%apelido%|%jogador%/gi, carts[cart].nickname).replace(/%amount%|%quantity%|%quantidade%/gi, carts[cart].items[item].quantity),
                slots_needed: parseInt(carts[cart].items[item].commands[command].slots, 10) || null,
                type: carts[cart].items[item].commands[command].offline_delivery == false ? 'ONLINE' : 'OFFLINE',
                status: 'FORWARDED'
              }, trx)
            } else {
              for (let i = 0; i < carts[cart].items[item].quantity; i++) {
                await StoreServerQueueItem.create({
                  uuid: uuid.v4(),
                  store_server_id: carts[cart].items[item].store_server_id,
                  store_cart_items_id: carts[cart].items[item].id,
                  nickname: carts[cart].nickname,
                  command: carts[cart].items[item].commands[command].command.replace(/%nickname%|%player%|%apelido%|%jogador%/gi, carts[cart].nickname),
                  slots_needed: parseInt(carts[cart].items[item].commands[command].slots, 10) || null,
                  type: carts[cart].items[item].commands[command].offline_delivery == false ? 'ONLINE' : 'OFFLINE',
                  status: 'FORWARDED'
                }, trx)
              }
            }
          }
        }

        await trx.commit()
      } catch (err) {
        Logger.error(`O carrinho de id ${carts[cart].id} não pôde ser despachado e passou por um rollback`, err)
        await trx.rollback()
      }
    }
  }

  async getPaidCarts () {
    let carts = await StoreCart
    .query()
    .setVisible(['id', 'nickname'])
    .where('status', 'PAYMENT_ACCEPTED')
    .andWhere('dispatched', false)
    .fetch()

    try {
      carts = carts.toJSON()
    } catch (err) {}

    return carts
  }

  async getCartItems (cartId) {
    let items = await StoreCartItem
    .query()
    .setVisible(['id', 'store_product_id', 'quantity'])
    .where('store_product_id', 'is not', null)
    .andWhere('store_cart_id', cartId)
    .fetch()

    try {
      items = items.toJSON()
    } catch (err) {}

    return items
  }

  async getProductServerId (productId) {
    let product = await StoreProduct
    .query()
    .setVisible(['id', 'store_server_id'])
    .where('id', productId)
    .first()

    try {
      product = product.toJSON()
    } catch (err) {}

    return product.store_server_id
  }

  async getProductCommands (productId) {
    let commands = await StoreProductCommand
    .query()
    .setVisible(['command', 'slots', 'offline_delivery', 'trigger'])
    .where('store_product_id', productId)
    .fetch()

    try {
      commands = commands.toJSON()
    } catch (err) {}

    return commands
  }
}

module.exports = ForwardCommandController
