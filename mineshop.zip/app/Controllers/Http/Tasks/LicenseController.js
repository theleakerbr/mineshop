'use strict'

const Database = use('Database')
const Logger = use('Logger')

const Store = use('App/Models/Store')

class LicenseController {
  async update () {
    let stores = await Store
    .query()
    .where('plan', 'PROFISSIONAL')
    .andWhere('status', 'ACTIVE')
    .fetch()

    try {
      stores = stores.toJSON()
    } catch (err) {}

    const trx = await Database.beginTransaction()

    try {
      for (let i = 0; i < stores.length; i++) {
        const store = await Store.find(stores[i].id)

        if (stores[i].days_remaining > -3) {
          store.merge({
            days_remaining: stores[i].days_remaining - 1,
            status: 'ACTIVE'
          })
        } else {
          store.merge({
            status: 'SUSPENDED'
          })
        }

        await store.save(trx)
      }

      await trx.commit()
    } catch (err) {
      await trx.rollback()
      Logger.error(`Não foi possível executar a task: license`, err)
    }
  }
}

module.exports = LicenseController
