'use strict'

const { validateAll, sanitize, rule } = use('Validator')

const Database = use('Database')
const Route = use('Route')

const Store = use('App/Models/Store')
const StoreSetting = use('App/Models/StoreSetting')
const UserAcl = use('App/Models/UserAcl')
const User = use('App/Models/User')

class StoreController {
  async show ({ request, response, view }) {
    let acls = await UserAcl
    .query()
    .setVisible(['store_id', 'owner'])
    .where('user_id', request.user.id)
    .orderBy('created_at', 'desc')
    .fetch()

    try {
      acls = acls.toJSON()
    } catch (err) {
      acls = []
    }

    let stores = {}

    for (let i = 0; i < acls.length; i++) {
      let tmp1 = await Store
      .query()
      .where('id', acls[i].store_id)
      .first()

      tmp1 = tmp1.toJSON()

      let tmp2 = await StoreSetting
      .query()
      .setVisible(['name'])
      .where('store_id', acls[i].store_id)
      .first()

      tmp2 = tmp2.toJSON()

      stores[i] = {
        id: tmp1.id,
        address: tmp1.address,
        days_remaining: tmp1.days_remaining,
        plan: tmp1.plan,
        status: tmp1.status,
        owner: acls[i].owner,
        name: tmp2.name
      }
    }

    if (Object.keys(stores).length > 0) {
      return view.render('panel.stores.stores', {
        stores: stores
      })
    }

    response.redirect(Route.url('panel.stores.new.show'))
  }

  async update ({ request, response }) {
    const sanitizeRules = {
      storeId: 'to_int'
    }

    const rules = {
      storeId: 'required|integer'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'integer': 'Esse campo deve ser do tipo inteiro.'
    }

    const params = sanitize(request.only(['storeId']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      let acl = await UserAcl
      .query()
      .where('store_id', params.storeId)
      .andWhere('user_id', request.user.id)
      .first()

      try {
        acl = acl.toJSON()
      } catch (err) {}

      if (!acl) {
        return response.status(422).send({
          error: { storeId: 'Desculpe, mas não encontramos nenhuma loja com esse id em sua conta. Por favor, experimente atualizar a página para tentar resolver o problema.' }
        })
      }

      const user = await User.find(request.user.id)

      user.merge({
        manage_store: params.storeId
      })

      await user.save()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async delete ({ request, response }) {
    const sanitizeRules = {
      storeId: 'to_int'
    }

    const rules = {
      storeId: 'required|integer'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'integer': 'Esse campo deve ser do tipo inteiro.'
    }

    const params = sanitize(request.only(['storeId']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      let acl = await UserAcl
      .query()
      .where('store_id', params.storeId)
      .andWhere('user_id', request.user.id)
      .first()

      try {
        acl = acl.toJSON()
      } catch (err) {}

      if (!acl) {
        return response.status(422).send({
          error: { storeId: 'Desculpe, mas não encontramos nenhuma loja com esse id em sua conta. Por favor, experimente atualizar a página para tentar resolver o problema.' }
        })
      }

      if (!acl.owner) {
        return response.status(422).send({
          error: { storeId: 'Você não tem permissão para fazer isso! Entre em contato com o dono da loja para solicitar acesso.' }
        })
      }

      const trx = await Database.beginTransaction()

      try {
        await User
        .query()
        .where('manage_store', params.storeId)
        .update({
          manage_store: null
        }, trx)

        const store = await Store.find(params.storeId)
        await store.delete(trx)

        await trx.commit()
      } catch (err) {
        await trx.rollback()
        throw new Error(err)
      }
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }
}

module.exports = StoreController
