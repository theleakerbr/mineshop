'use strict'

const { validateAll, sanitize, rule } = use('Validator')

const Hash = use('Hash')

const User = use('App/Models/User')
const UserSession = use('App/Models/UserSession')

class MeController {
  async show ({ request, view }) {
    return view.render('panel.me.me', { user: request.user })
  }

  async showChangePassword ({ view }) {
    return view.render('panel.me.password')
  }

  async showChangeEmail ({ view }) {
    return view.render('panel.me.email')
  }

  async changePersonalData({ request, response }) {
    const sanitizeRules = {
      first_name: 'trim',
      surname: 'trim',
      phone: 'trim',
      discord_tag: 'trim'
    }

    const rules = {
      first_name: 'min:2|max:15',
      surname: 'min:2|max:50',
      phone: [rule('regex', /^[0-9]{10,11}$/)],
      discord_tag: 'min:2|max:32'
    }

    const messages = {
      'min': 'Esse campo precisa ter no mínimo {{ argument.0 }} caracteres.',
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres.',
      'regex': 'Esse número de telefone não é um número válido.'
    }

    const params = sanitize(request.only(['first_name', 'surname', 'phone', 'discord_tag']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      const user = await User
      .query()
      .where('id', request.user.id)
      .first()

      for (let field in params) {
        if (field === 'first_name' || field === 'surname') {
          params[field] = params[field].replace(/\w\S*/g, (string) => {
            return string.charAt(0).toUpperCase() + string.substr(1).toLowerCase()
          }).replace(/\s+/g, ' ')
        }

        user.merge({
          [field]: params[field] ? params[field] : null
        })
      }

      await user.save()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async changeEmail ({ request, response }) {
    const sanitizeRules = {
      newEmail: 'trim|normalize_email',
      confirmNewEmail: 'trim|normalize_email',
      password: 'trim'
    }

    const rules = {
      newEmail: 'required|email',
      confirmNewEmail: 'required|email',
      password: 'required'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'email': 'O endereço de email informado é inválido.'
    }

    const params = sanitize(request.only(['newEmail', 'confirmNewEmail', 'password']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      if (params.newEmail !== params.confirmNewEmail) {
        return response.status(422).send({
          error: {
            confirmNewEmail: 'Esse e-mail não é igual ao informado anteriormente.'
          }
        })
      }

      const user = await User
      .query()
      .where('id', request.user.id)
      .first()

      const isSame = await Hash.verify(params.password, user.password)

      if (!isSame) {
        return response.status(422).send({
          error: {
            password: 'Senha incorreta.'
          }
        })
      }

      if (params.newEmail === user.email) {
        return response.status(422).send({
          error: {
            newEmail: 'Informe um e-mail diferente do que você já está utilizando.'
          }
        })
      }

      let emailInUse = await User
      .query()
      .where('email', params.newEmail)
      .first()

      emailInUse = emailInUse === null ? false : true

      if (emailInUse) {
        return response.status(422).send({
          error: {
            newEmail: 'Esse e-mail já está sendo utilizado por outra pessoa.'
          }
        })
      }

      user.merge({
        email: params.newEmail,
        is_verified: false
      })

      await user.save()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async changePassword ({ request, response }) {
    const sanitizeRules = {
      newPassword: 'trim',
      confirmNewPassword: 'trim',
      password: 'trim'
    }

    const rules = {
      newPassword: 'required|min:6|max:255',
      confirmNewPassword: 'required|min:6|max:255',
      password: 'required'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'min': 'Esse campo precisa ter no mínimo {{ argument.0 }} caracteres',
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres'
    }

    const params = sanitize(request.only(['newPassword', 'confirmNewPassword', 'password']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      if (params.newPassword !== params.confirmNewPassword) {
        return response.status(422).send({
          error: {
            confirmNewPassword: 'Essa senha não é igual a informada anteriormente.'
          }
        })
      }

      const user = await User
      .query()
      .where('id', request.user.id)
      .first()

      const isSame = await Hash.verify(params.password, user.password)

      if (!isSame) {
        return response.status(422).send({
          error: {
            password: 'Senha atual incorreta.'
          }
        })
      }

      user.merge({ password: params.newPassword })

      await user.save()

      await UserSession
      .query()
      .where('user_id', request.user.id)
      .update({ active: 0 })
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }
}

module.exports = MeController
