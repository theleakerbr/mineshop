'use strict'

const _ = use('lodash')
const { validateAll, sanitize } = use('Validator')
const Database = use('Database')

const User = use('App/Models/User')
const UserAcl = use('App/Models/UserAcl')

class StoreOperatorController {
  async show ({ request, view }) {
    let operators = await UserAcl
    .query()
    .where('store_id', request.user.manage_store)
    .orderBy('owner', 'desc')
    .fetch()

    try {
      operators = operators.toJSON()
    } catch (err) {}

    for (let i = 0; i < operators.length; i++) {
      let user = await User
      .query()
      .where('id', operators[i].user_id)
      .first()

      try {
        user = user.toJSON()
      } catch (err) {}

      operators[i].email = user.email
      operators[i].first_name = user.first_name,
      operators[i].surname = user.surname,
      operators[i].tfa = user.tfa ? true : false
    }

    return view.render('panel.store.operators.operators', {
      operators: operators
    })
  }

  async create ({ request, response }) {
    const sanitizeRules = {
      email: 'trim|normalize_email'
    }

    const rules = {
      email: 'required|email'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'email': 'O endereço de email informado é inválido.'
    }

    const params = sanitize(request.only(['email']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      let acls = await UserAcl
      .query()
      .where('store_id', request.user.manage_store)
      .fetch()

      try {
        acls = acls.toJSON()
      } catch (err) {}

      if (acls.length >= 7) {
        return response.status(403).send({
          error: { other: 'O limite de participantes nesta equipe foi atingido.' }
        })
      }

      const user = await User
      .query()
      .where('email', params.email)
      .first()

      if (!user) {
        return response.status(422).send({
          error: { email: 'Este endereço e-mail não pertence a nenhuma conta cadastrada conosco.' }
        })
      }

      const acl = await UserAcl
      .query()
      .where('store_id', request.user.manage_store)
      .andWhere('user_id', user.id)
      .first()

      if (acl) {
        return response.status(422).send({
          error: { email: 'Oops! Este usuário já está participando desta equipe.' }
        })
      }

      await UserAcl.create({
        user_id: user.id,
        store_id: request.user.manage_store,
        owner: 0
      })
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async update ({ request, response }) {
    const permissions = _.mapValues(request.only(['news', 'servers', 'products', 'coupons', 'operators', 'appearance', 'settings', 'logs', 'license']), (value) => {
      const newValue = _.parseInt(_.trim(value))

      if (newValue >= 0 && newValue <= 3) {
        return newValue
      }

      return 0
    })

    const operatorId = _.parseInt(request.input('id'))

    const origin = await UserAcl
    .query()
    .where('store_id', request.user.manage_store)
    .andWhere('user_id', request.user.id)
    .first()

    const target = await UserAcl
    .query()
    .where('store_id', request.user.manage_store)
    .andWhere('user_id', operatorId)
    .first()

    if (!target) {
      return response.status(422).send({
        error: { id: 'O usuário informado não está participando desta equipe.' }
      })
    }

    if (target.owner === 1 && origin.owner === 0) {
      return response.status(422).send({
        error: { id: 'Você não tem permissão para editar as permissões deste usuário.' }
      })
    }

    target.merge({
      news: permissions.news,
      servers: permissions.servers,
      products: permissions.products,
      coupons: permissions.coupons,
      operators: permissions.operators,
      appearance: permissions.appearance,
      settings: permissions.settings,
      logs: permissions.logs,
      license: permissions.license
    })

    await target.save()
  }

  async delete ({ request, response }) {
    const operatorId = _.parseInt(request.input('id'))

    if (!_.isInteger(operatorId)) {
      return response.status(422).send({
        error: { id: 'O campo id suporta apenas caracteres numéricos.' }
      })
    }

    const origin = await UserAcl
    .query()
    .where('store_id', request.user.manage_store)
    .andWhere('user_id', request.user.id)
    .first()

    const target = await UserAcl
    .query()
    .where('store_id', request.user.manage_store)
    .andWhere('user_id', operatorId)
    .first()

    if (!target) {
      return response.status(422).send({
        error: { id: 'O usuário informado não está participando desta equipe.' }
      })
    }

    if (target.owner === 1) {
      if (origin.owner === 0) {
        return response.status(422).send({
          error: { id: 'Você não tem permissão para expulsar este usuário.' }
        })
      }

      let acls = await UserAcl
      .query()
      .where('store_id', request.user.manage_store)
      .andWhere('user_id', '!=', target.user_id)
      .andWhere('owner', 1)
      .fetch()

      try {
        acls = acls.toJSON()
      } catch (err) {}

      if (acls.length < 1) {
        return response.status(422).send({
          error: { id: 'Você não pode sair desta equipe porque, atualmente, você é o único dono.' }
        })
      }
    }

    const trx = await Database.beginTransaction()

    const operator = await User.find(target.user_id)

    operator.merge({
      manage_store: null
    })

    try {
      await operator.save(trx)
      await target.delete(trx)
      await trx.commit()
    } catch (err) {
      await trx.rollback()
      return response.status(500).send({
        error: { id: 'Algo não saiu como esperado e tivemos que reverter sua última operação.' }
      })
    }
  }
}

module.exports = StoreOperatorController
