'use strict'

const { validateAll, sanitize } = use('Validator')
const uuid = use('uuid')

const User = use('App/Models/User')
const UserRecovery = use('App/Models/UserRecovery')

class RecoveryController {
  async show ({ view }) {
    return view.render('panel.recovery')
  }

  async createToken ({ request, response }) {
    const sanitizeRules = {
      email: 'trim|normalize_email'
    }

    const rules = {
      email: 'required|email'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'email': 'O endereço de email informado é inválido.'
    }

    const params = sanitize(request.only(['email']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      let user = await User
      .query()
      .where('email', params.email)
      .first()

      try {
        user = user.toJSON()
      } catch (err) {}

      if (!user) {
        return response.status(422).send({
          error: {
            email: 'Esse e-mail não percente a nenhum usuário cadastrado'
          }
        })
      }

      const userRecovery = new UserRecovery()

      userRecovery.fill({
        user_id: user.id,
        token: uuid.v4(),
        active: true,
        remote_addr: request.ip(),
        user_agent: request.header('User-Agent')
      })

      await userRecovery.save()

      //TODO: Enviar e-mail de rec. de conta
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }
}

module.exports = RecoveryController
