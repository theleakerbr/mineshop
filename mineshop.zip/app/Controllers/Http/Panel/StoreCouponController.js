'use strict'

const { validateAll, sanitize, rule } = use('Validator')

const StoreDiscountCoupon = use('App/Models/StoreDiscountCoupon')

class StoreCouponController {
  async show ({ request, view }) {
    let coupons = await StoreDiscountCoupon
    .query()
    .where('store_id', request.user.manage_store)
    .orderBy('code', 'asc')
    .fetch()

    try {
      coupons = coupons.toJSON()
    } catch (err) {}

    return view.render('panel.store.coupons.coupons', {
      coupons: coupons
    })
  }

  async create ({ request, response }) {
    const sanitizeRules = {
      code: 'trim',
      discount: 'to_int'
    }

    const rules = {
      code: [
        rule('required'),
        rule('min', 3),
        rule('max', 20),
        rule('regex', /^[a-zA-Z0-9]*$/)
      ],
      discount: 'required|integer'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'integer': 'Informe um valor numérico entre 1 e 100 no campo de desconto.',
      'min': 'Esse campo precisa ter no mínimo {{ argument.0 }} caracteres.',
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres.',
      'regex': 'Esse campo suporta apenas caracteres alfanuméricos.'
    }

    const params = sanitize(request.only(['code', 'discount']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      params.code = params.code.toUpperCase()

      if (params.discount < 1 || params.discount > 100) {
        return response.status(422).send({
          error: { discount: 'Informe um valor entre 1 e 100 no campo de desconto.' }
        })
      }

      const coupon = await StoreDiscountCoupon
      .query()
      .where('code', params.code)
      .andWhere('store_id', request.user.manage_store)
      .first()

      if (coupon) {
        return response.status(422).send({
          error: { code: 'Você já tem um cupom de desconto cadastrado com esse código.' }
        })
      }

      await StoreDiscountCoupon.create({
        store_id: request.user.manage_store,
        code: params.code,
        discount: params.discount
      })
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async update ({ request, response }) {
    const sanitizeRules = {
      id: 'to_int',
      code: 'trim',
      discount: 'to_int'
    }

    const rules = {
      id: 'required',
      code: [
        rule('min', 3),
        rule('max', 20),
        rule('regex', /^[a-zA-Z0-9]*$/)
      ],
      discount: 'integer'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'integer': 'Informe um valor numérico entre 1 e 100 no campo de desconto.',
      'min': 'Esse campo precisa ter no mínimo {{ argument.0 }} caracteres.',
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres.',
      'regex': 'Esse campo suporta apenas caracteres alfanuméricos.'
    }

    const params = sanitize(request.only(['id', 'code', 'discount']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      const coupon = await StoreDiscountCoupon
      .query()
      .where('id', params.id)
      .andWhere('store_id', request.user.manage_store)
      .first()

      if (params.code) {
        const tmp = await StoreDiscountCoupon
        .query()
        .where('code', params.code)
        .andWhere('store_id', request.user.manage_store)
        .first()

        if (tmp) {
          return response.status(422).send({
            error: { code: 'Você já tem um cupom de desconto cadastrado com esse código.' }
          })
        }

        coupon.merge({
          code: params.code.toUpperCase()
        })
      }

      if (params.discount) {
        if (params.discount < 1 || params.discount > 100) {
          return response.status(422).send({
            error: { discount: 'Informe um valor entre 1 e 100 no campo de desconto.' }
          })
        }

        coupon.merge({
          discount: params.discount
        })
      }

      await coupon.save()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async delete ({ request, response }) {
    const sanitizeRules = {
      id: 'to_int'
    }

    const rules = {
      id: 'required'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.'
    }

    const params = sanitize(request.only(['id']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      const coupon = await StoreDiscountCoupon
      .query()
      .where('id', params.id)
      .andWhere('store_id', request.user.manage_store)
      .first()

      await coupon.delete()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }
}

module.exports = StoreCouponController
