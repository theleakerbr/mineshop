'use strict'

const Drive = use('Drive')
const Env = use('Env')
const uuid = use('uuid')
const Encryption = use('Encryption')

class UploadImageController {
  async create ({ request, response }) {
    request.multipart.file('image', {}, async (file) => {
      file.extname = file.extname.trim().toLowerCase()

      if (file.type !== 'image') {
        return response.status(422).send({
          error: { image: 'Não suportamos uploads deste tipo de arquivo.' }
        })
      }

      if (['png', 'jpg', 'jpeg'].indexOf(file.extname) === -1) {
        return response.status(422).send({
          error: { image: 'A extensão do arquivo enviado não é suportada.' }
        })
      }

      const path = `uploads/${uuid.v4()}.${file.extname}`

      await Drive.disk('spaces').put(path, file.stream, {
        ACL: 'public-read',
        ContentType: `${file.type}/${file.subtype}`,
        CacheControl: 'public, max-age=2592000',
        Metadata: { uploadedBy: Encryption.encrypt(request.user.id) }
      })

      return response.status(201).send({
        url: `/${path}`,
        fullUrl: `${Env.get('CDN')}/${path}`
      })
    })

    await request.multipart.process()
  }
}

module.exports = UploadImageController
