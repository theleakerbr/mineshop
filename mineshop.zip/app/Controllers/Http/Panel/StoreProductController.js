'use strict'

const { validateAll, sanitize, rule } = use('Validator')
const _ = use('lodash')
const cpf = use('cpf')
const moment = use('moment')

const StoreCart = use('App/Models/StoreCart')
const StoreCartItem = use('App/Models/StoreCartItem')
const StoreProduct = use('App/Models/StoreProduct')
const StoreProductCommand = use('App/Models/StoreProductCommand')
const StoreServer = use('App/Models/StoreServer')
const StoreServerQueueItem = use('App/Models/StoreServerQueueItem')

class StoreProductController {
  async show ({ request, view }) {
    let products = await StoreProduct
    .query()
    .where('store_id', request.user.manage_store)
    .orderBy('position', 'asc')
    .fetch()

    try {
      products = products.toJSON()
    } catch (err) {}

    for (let i = 0; i < products.length; i++) {
      let server = await StoreServer
      .query()
      .where('id', products[i].store_server_id)
      .andWhere('store_id', request.user.manage_store)
      .first()

      try {
        server = server.toJSON()
      } catch (err) {}

      products[i]['server_name'] = server ? server.name : 'N/A'
    }

    return view.render('panel.store.products.products', {
      products: products
    })
  }

  async newShowPage ({ request, view }) {
    let servers = await StoreServer
    .query()
    .where('store_id', request.user.manage_store)
    .fetch()

    try {
      servers = servers.toJSON()
    } catch (err) {}

    return view.render('panel.store.products.new', {
      servers: servers
    })
  }

  async editShowPage ({ request, view, params }) {
    const productId = params.id

    let product = await StoreProduct
    .query()
    .where('store_id', request.user.manage_store)
    .andWhere('id', productId)
    .first()

    try {
      product = product.toJSON()
    } catch (err) {}

    let commands = await StoreProductCommand
    .query()
    .where('store_product_id', product.id)
    .fetch()

    try {
      commands = commands.toJSON()
    } catch (err) {}

    let servers = await StoreServer
    .query()
    .where('store_id', request.user.manage_store)
    .fetch()

    try {
      servers = servers.toJSON()
    } catch (err) {}

    return view.render('panel.store.products.edit', {
      product: product,
      commands: JSON.stringify(commands),
      servers: servers
    })
  }

  async salesPage ({ request, view }) {
    return view.render('panel.store.products.sales')
  }

  async salesStatistics ({ request, response, params }) {
    let { period } = params

    if (!_.isInteger(period) && !_.isString(period)) {
      return response.status(422).send({
        error: { period: 'O período informado é inválido' }
      })
    }

    if (_.isEqual(period, 'today')) {
      let sales = await StoreCart
      .query()
      .where('store_id', request.user.manage_store)
      .andWhere('status', 'PAYMENT_ACCEPTED')
      .andWhere('updated_at', '>=', moment().startOf('day').format('YYYY-MM-DD HH:mm:ss'))
      .fetch()

      sales = sales.toJSON()

      let todayAmount = 0

      for (let sale in sales) {
        todayAmount += sales[sale].total
      }

      return {
        statistic: 'today',
        amount: todayAmount
      }
    }

    if (_.isEqual(period, 'week')) {
      let sales = await StoreCart
      .query()
      .where('store_id', request.user.manage_store)
      .andWhere('status', 'PAYMENT_ACCEPTED')
      .andWhere('updated_at', '>=', moment().startOf('week').format('YYYY-MM-DD HH:mm:ss'))
      .fetch()

      sales = sales.toJSON()

      let weekAmount = 0

      for (let sale in sales) {
        weekAmount += sales[sale].total
      }

      return {
        statistic: 'week',
        amount: weekAmount
      }
    }

    period = _.toInteger(period)

    if (_.isNaN(period) || !_.isInteger(period)) {
      return response.status(422).send({
        error: { period: 'O período informado é inválido' }
      })
    }

    if (period < 2) {
      period = 2
    }

    if (period > 180) {
      period = 180
    }

    let sales = await StoreCart
    .query()
    .where('store_id', request.user.manage_store)
    .andWhere('status', 'PAYMENT_ACCEPTED')
    .andWhere('updated_at', '>=', moment().subtract(period, 'days').format('YYYY-MM-DD HH:mm:ss'))
    .fetch()

    sales = sales.toJSON()

    let customAmount = 0

    for (let sale in sales) {
      customAmount += sales[sale].total
    }

    return {
      statistic: 'custom',
      amount: customAmount
    }
  }

  async salesPagination ({ request, response, params }) {
    const { filter } = _.mapValues(params, (value) => {
      if (_.isString(value)) {
        return _.toLower(_.trim(decodeURI(value)))
      }

      return value
    })

    if (_.isEqual(filter, '*')) {
      const sales = await StoreCart
      .query()
      .setHidden(['store_id', 'context'])
      .where('store_id', request.user.manage_store)
      .andWhere('status', '!=', 'OPENED')
      .orderBy('id', 'desc')
      .fetch()

      return sales.toJSON()
    }

    const sales = await StoreCart
    .query()
    .setHidden(['store_id', 'context'])
    .where('store_id', request.user.manage_store)
    .andWhere('status', '!=', 'OPENED')
    .andWhere('nickname', 'LIKE', `%${filter}%`)
    .orWhere('store_id', request.user.manage_store)
    .andWhere('status', '!=', 'OPENED')
    .andWhere('email', 'LIKE', `%${filter}%`)
    .orWhere('store_id', request.user.manage_store)
    .andWhere('status', '!=', 'OPENED')
    .andWhere('coupon_code', 'LIKE', `%${filter}%`)
    .orWhere('store_id', request.user.manage_store)
    .andWhere('status', '!=', 'OPENED')
    .andWhere('ipn_token', 'LIKE', `%${filter}%`)
    .orWhere('store_id', request.user.manage_store)
    .andWhere('status', '!=', 'OPENED')
    .andWhere('remote_addr', 'LIKE', `%${filter}%`)
    .orWhere('store_id', request.user.manage_store)
    .andWhere('status', '!=', 'OPENED')
    .andWhere('payment_method', 'LIKE', `%${filter.replace(/\s/g, '').replace('pagseguro', 'PAGSEGURO').replace('mercadopago', 'MERCADOPAGO').replace('paypal', 'PAYPAL')}%`)
    .orWhere('store_id', request.user.manage_store)
    .andWhere('status', '!=', 'OPENED')
    .andWhere('status', 'LIKE', `%${filter.replace('aguardando pagamento', 'AWAITING_PAYMENT').replace('pagamento aprovado', 'PAYMENT_ACCEPTED').replace('pagamento recusado', 'PAYMENT_REFUSED').replace('PAYMENT_REFUNDED', 'pagamento devolvido').replace('pagamento cancelado', 'PAYMENT_CANCELED')}%`)
    .orWhere('store_id', request.user.manage_store)
    .andWhere('status', '!=', 'OPENED')
    .andWhere('context', 'LIKE', `%${filter}%`)
    .orderBy('id', 'desc')
    .fetch()

    return sales.toJSON()
  }

  async saleDetails ({ request, response, params }) {
    const { id } = _.mapValues(params, (value) => {
      if (!_.isInteger(value)) {
        value = _.toInteger(value)
      }

      return _.isInteger(value) ? value : 0
    })

    if (!id) {
      return response.status(422).send({
        error: { id: 'O id informado não está em um formato válido.' }
      })
    }

    let cart = await StoreCart
    .query()
    .setHidden(['store_id'])
    .where('store_id', request.user.manage_store)
    .andWhere('status', '!=', 'OPENED')
    .andWhere('id', id)
    .first()

    try {
      cart = cart.toJSON()
    } catch (err) {}

    if (!cart) {
      return response.status(422).send({
        error: { id: 'Nenhum carrinho foi encontrado com o id informado.' }
      })
    }

    cart.context = JSON.parse(cart.context)
    cart.payment = null

    if (cart.context) {
      switch (cart.payment_method) {
        case 'PAYPAL':
          cart.payment = {
            gateway: 'PayPal',
            reference: cart.context.transactions[0].related_resources[0].sale.id,
            payer: {
              email: cart.context.payer.payer_info.email,
              name: `${cart.context.payer.payer_info.first_name} ${cart.context.payer.payer_info.last_name}`,
              document: `Account ID ${cart.context.payer.payer_info.payer_id}`
            }
          }

          break
        case 'MERCADOPAGO':
          let formatedDocument = cart.context.payer.identification.number

          try {
            formatedDocument = cpf.format(formatedDocument)
          } catch (err) {}

          cart.payment = {
            gateway: 'Mercado Pago',
            reference: cart.ipn_token,
            payer: {
              email: cart.context.payer.email,
              name: `${cart.context.payer.first_name} ${cart.context.payer.last_name}`,
              document: formatedDocument || 'N/A'
            }
          }

          break
        case 'PAGSEGURO':
          cart.payment = {
            gateway: 'PagSeguro',
            reference: cart.ipn_token,
            payer: {
              email: cart.context.transaction.sender[0].email[0],
              name: cart.context.transaction.sender[0].name[0],
              document: 'N/A'
            }
          }

          break
      }
    }

    cart.context = null

    cart.items = await StoreCartItem
    .query()
    .where('store_cart_id', cart.id)
    .fetch()

    try {
      cart.items = cart.items.toJSON()
    } catch (err) {}

    for (let item in cart.items) {
      cart.items[item].commands = await StoreServerQueueItem
      .query()
      .setHidden(['uuid'])
      .where('store_cart_items_id', cart.items[item].id)
      .fetch()

      try {
        cart.items[item].commands = cart.items[item].commands.toJSON()
      } catch (err) {}

      cart.items[item].product = await StoreProduct
      .query()
      .setHidden(['commands'])
      .where('id', cart.items[item].store_product_id)
      .first()

      try {
        cart.items[item].product = cart.items[item].product.toJSON()
      } catch (err) {}
    }

    cart.created_at = moment(cart.created_at).format('LLL')
    cart.updated_at = moment(cart.updated_at).format('LLL')

    return cart
  }

  async update ({ request, response }) {
    const sanitizeRules = {
      id: 'to_int'
    }

    const rules = {
      id: 'required'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.'
    }

    const params = sanitize(request.only(['id']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      const product = await StoreProduct
      .query()
      .where('store_id', request.user.manage_store)
      .andWhere('id', params.id)
      .first()

      if (!product) {
        return response.status(422).send({
          error: { id: 'Oops! Parece que este produto não existe mais.' }
        })
      }

      product.merge({
        available: product.available ? 0 : 1
      })

      await product.save()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async delete ({ request, response }) {
    const sanitizeRules = {
      id: 'to_int'
    }

    const rules = {
      id: 'required'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.'
    }

    const params = sanitize(request.only(['id']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      const product = await StoreProduct
      .query()
      .where('store_id', request.user.manage_store)
      .andWhere('id', params.id)
      .first()

      if (!product) {
        return response.status(422).send({
          error: { id: 'Oops! Parece que o produto que você está tentando excluir não existe mais.' }
        })
      }

      await product.delete()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async newProduct ({ request, response }) {
    const sanitizeRules = {
      name: 'trim',
      image: 'trim',
      price: 'trim',
      position: 'to_int',
      buyLabel: 'trim',
      server: 'to_int',
      minAmount: 'to_int',
      maxAmount: 'to_int',
      commands: 'trim',
      description: 'trim'
    }

    const rules = {
      name: 'required|max:30',
      image: 'max:255',
      price: 'required|max:6',
      position: 'integer',
      buyLabel: 'max:30',
      server: 'required|integer',
      minAmount: 'integer',
      maxAmount: 'integer',
      commands: 'required'
    }

    const messages = {
      'required': 'Este campo é obrigatório',
      'integer': 'Este campo aceita apenas valores numéricos',
      'server.integer': 'Você deve selecionar um servidor',
      'max': 'Este campo não pode ter mais de {{ argument.0 }} caracteres'
    }

    const paramsValidator = sanitize(request.only(['name', 'image', 'price', 'position', 'buyLabel', 'server', 'minAmount', 'maxAmount', 'commands', 'description']), sanitizeRules)
    const validation = await validateAll(paramsValidator, rules, messages)

    if (!validation.fails()) {
      paramsValidator.price = parseFloat(paramsValidator.price.replace(',', '.'))
      paramsValidator.position = paramsValidator.position > 0 && paramsValidator.position < 10000 ? paramsValidator.position : 1
      paramsValidator.commands = JSON.parse(paramsValidator.commands)

      if (paramsValidator.price < 0) {
        return response.status(422).send({
          error: { price: 'O preço do seu produto deve ser igual ou maior que R$ 0,00' }
        })
      }

      for (let i = 0; i < paramsValidator.commands.length; i++) {
        if (typeof paramsValidator.commands[i].command === 'undefined' || typeof paramsValidator.commands[i].slots === 'undefined' || typeof paramsValidator.commands[i].offline_delivery === 'undefined') {
          return response.status(422).send({
            error: { commands: 'O formato do JSON de comandos passado não é reconhecido' }
          })
        }
      }

      let storeServer = await StoreServer
      .query()
      .where('store_id', request.user.manage_store)
      .andWhere('id', paramsValidator.server)
      .first()

      try {
        storeServer = storeServer.toJSON()
      } catch (err) {}

      if (!storeServer) {
        return response.status(422).send({
          error: { server: 'O servidor informado não foi encontrado' }
        })
      }

      const product = await StoreProduct.create({
        store_id: request.user.manage_store,
        store_server_id: paramsValidator.server,
        name: paramsValidator.name,
        image: paramsValidator.image || null,
        description: paramsValidator.description || null,
        price: paramsValidator.price,
        min: paramsValidator.minAmount || null,
        max: paramsValidator.maxAmount || null,
        buy_label: paramsValidator.buyLabel || null,
        position: paramsValidator.position || 1,
        available: true
      })

      for (let i = 0; i < paramsValidator.commands.length; i++) {
        await StoreProductCommand.create({
          store_product_id: product.id,
          command: _.trimStart(paramsValidator.commands[i].command, '/'),
          slots: paramsValidator.commands[i].slots || 0,
          offline_delivery: paramsValidator.commands[i].offline_delivery || false,
          trigger: 'PAYMENT_ACCEPTED'
        })
      }
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async editUpdate ({ request, response, params }) {
    const sanitizeRules = {
      name: 'trim',
      image: 'trim',
      price: 'trim',
      position: 'to_int',
      buyLabel: 'trim',
      server: 'to_int',
      minAmount: 'to_int',
      maxAmount: 'to_int',
      commands: 'trim',
      description: 'trim'
    }

    const rules = {
      name: 'required|max:30',
      image: 'max:255',
      price: 'required|max:6',
      position: 'integer',
      buyLabel: 'max:30',
      server: 'required|integer',
      minAmount: 'integer',
      maxAmount: 'integer',
      commands: 'required'
    }

    const messages = {
      'required': 'Este campo é obrigatório',
      'integer': 'Este campo aceita apenas valores numéricos',
      'server.integer': 'Você deve selecionar um servidor',
      'max': 'Este campo não pode ter mais de {{ argument.0 }} caracteres'
    }

    const paramsValidator = sanitize(request.only(['name', 'image', 'price', 'position', 'buyLabel', 'server', 'minAmount', 'maxAmount', 'commands', 'description']), sanitizeRules)
    const validation = await validateAll(paramsValidator, rules, messages)

    if (!validation.fails()) {
      paramsValidator.price = parseFloat(paramsValidator.price.replace(',', '.'))
      paramsValidator.position = paramsValidator.position > 0 && paramsValidator.position < 10000 ? paramsValidator.position : 1
      paramsValidator.commands = JSON.parse(paramsValidator.commands)

      if (paramsValidator.price < 0) {
        return response.status(422).send({
          error: { price: 'O preço do seu produto deve ser igual ou maior que R$ 0,00' }
        })
      }

      for (let i = 0; i < paramsValidator.commands.length; i++) {
        if (typeof paramsValidator.commands[i].command === 'undefined' || typeof paramsValidator.commands[i].slots === 'undefined' || typeof paramsValidator.commands[i].offline_delivery === 'undefined') {
          return response.status(422).send({
            error: { commands: 'O formato do JSON de comandos passado não é reconhecido' }
          })
        }
      }

      let storeServer = await StoreServer
      .query()
      .where('store_id', request.user.manage_store)
      .andWhere('id', paramsValidator.server)
      .first()

      try {
        storeServer = storeServer.toJSON()
      } catch (err) {}

      if (!storeServer) {
        return response.status(422).send({
          error: { server: 'O servidor informado não foi encontrado' }
        })
      }

      const product = await StoreProduct
      .query()
      .where('store_id', request.user.manage_store)
      .andWhere('id', params.id)
      .first()

      if (!product) {
        return response.status(422).send({
          error: { other: 'Parece que este produto não existe mais' }
        })
      }

      product.merge({
        store_server_id: paramsValidator.server,
        name: paramsValidator.name,
        image: paramsValidator.image || null,
        description: paramsValidator.description || null,
        price: paramsValidator.price,
        min: paramsValidator.minAmount || null,
        max: paramsValidator.maxAmount || null,
        buy_label: paramsValidator.buyLabel || null,
        position: paramsValidator.position
      })

      await product.save()

      await StoreProductCommand
      .query()
      .where('store_product_id', product.id)
      .delete()

      for (let i = 0; i < paramsValidator.commands.length; i++) {
        await StoreProductCommand.create({
          store_product_id: product.id,
          command: _.trimStart(paramsValidator.commands[i].command, '/'),
          slots: paramsValidator.commands[i].slots || 0,
          offline_delivery: paramsValidator.commands[i].offline_delivery || false,
          trigger: 'PAYMENT_ACCEPTED'
        })
      }
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }
}

module.exports = StoreProductController
