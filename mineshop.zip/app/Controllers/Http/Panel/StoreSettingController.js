'use strict'

const { validateAll, sanitize, rule } = use('Validator')

const _ = use('lodash')

const Store = use('App/Models/Store')
const StoreSetting = use('App/Models/StoreSetting')
const StorePaymentGateway = use('App/Models/StorePaymentGateway')

class StoreSettingController {
  async show ({ request, view }) {
    let settings = await StoreSetting
    .query()
    .where('store_id', request.user.manage_store)
    .first()

    settings = settings.toJSON()

    return view.render('panel.store.settings.settings', {
      settings: settings
    })
  }

  async showAddressPage ({ view }) {
    return view.render('panel.store.settings.address.address')
  }

  async showAddressSuccess ({ view }) {
    return view.render('panel.store.settings.address.success')
  }

  async showLegalPage ({ request, view }) {
    let settings = await StoreSetting
    .query()
    .where('store_id', request.user.manage_store)
    .first()

    try {
      settings = settings.toJSON()
    } catch (err) {}

    return view.render('panel.store.settings.legal', {
      terms: settings.terms,
      refundPolicy: settings.refund_policy
    })
  }

  async showGatewaysPage ({ request, view }) {
    let paymentGateways = await StorePaymentGateway
    .query()
    .where('store_id', request.user.manage_store)
    .first()

    try {
      paymentGateways = paymentGateways.toJSON()
    } catch (err) {}

    return view.render('panel.store.settings.gateways', {
      paymentGateways: paymentGateways
    })
  }

  async update ({ request, response }) {
    const sanitizeRules = {
      name: 'trim',
      slogan: 'trim',
      analytics: 'trim',
      discord: 'trim',
      twitter: 'trim',
      color0: 'trim',
      color1: 'trim',
      color2: 'trim',
      color3: 'trim',
      color4: 'trim',
      color5: 'trim',
      color6: 'trim',
      color7: 'trim',
      color8: 'trim',
    }

    const rules = {
      name: 'max:20',
      slogan: 'max:50',
      analytics: 'max:20',
      discord: 'max:350',
      twitter: 'max:350',
      color0: [rule('regex', /^#([0-9a-f]{6}|[0-9a-f]{3})$/i)],
      color1: [rule('regex', /^#([0-9a-f]{6}|[0-9a-f]{3})$/i)],
      color2: [rule('regex', /^#([0-9a-f]{6}|[0-9a-f]{3})$/i)],
      color3: [rule('regex', /^#([0-9a-f]{6}|[0-9a-f]{3})$/i)],
      color4: [rule('regex', /^#([0-9a-f]{6}|[0-9a-f]{3})$/i)],
      color5: [rule('regex', /^#([0-9a-f]{6}|[0-9a-f]{3})$/i)],
      color6: [rule('regex', /^#([0-9a-f]{6}|[0-9a-f]{3})$/i)],
      color7: [rule('regex', /^#([0-9a-f]{6}|[0-9a-f]{3})$/i)],
      color8: [rule('regex', /^#([0-9a-f]{6}|[0-9a-f]{3})$/i)]
    }

    const messages = {
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres.',
      'regex': 'Essa não é uma representação hexadecimal de cor válida.'
    }

    const params = sanitize(request.only(['name', 'slogan', 'analytics', 'discord', 'twitter', 'color0', 'color1', 'color2', 'color3', 'color4', 'color5', 'color6', 'color7', 'color8']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      const setting = await StoreSetting
      .query()
      .where('store_id', request.user.manage_store)
      .first()

      for (let field in params) {
        if (field === 'name' || field === 'slogan' || field === 'analytics' || field === 'discord' || field === 'twitter') {
          if (field === 'analytics') {
            setting.merge({
              [field]: params[field] ? params[field].toUpperCase() : null
            })
          } else if (field === 'discord' || field === 'twitter') {
            setting.merge({
              [`${field}_widget`]: params[field] ? params[field] : null
            })
          } else {
            setting.merge({
              [field]: params[field] ? params[field] : null
            })
          }
        } else {
          let colors = JSON.parse(setting.colors) || {}

          if (params[field]) {
            colors[`--${field}`] = params[field].toLowerCase()
          } else {
            delete colors[`--${field}`]
          }

          colors = JSON.stringify(colors)

          setting.merge({
            colors: colors ? colors : null
          })
        }
      }

      await setting.save()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async updateAddress ({ request, response }) {
    const sanitizeRules = {
      newAddress: 'trim'
    }

    const rules = {
      newAddress: 'required|min:4|max:255'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'min': 'Esse campo precisa ter no mínimo {{ argument.0 }} caracteres.',
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres.'
    }

    const params = sanitize(request.only(['newAddress']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      let newAddressIsValid = false
      params.newAddress = params.newAddress.toLowerCase()

      if (/mineshop.com.br$/.test(params.newAddress)) {
        if (/^[a-zA-Z0-9]{4,25}.mineshop.com.br$/.test(params.newAddress)) {
          newAddressIsValid = !/^ms2$|^mineshop$|^loja$|^lojas$|^black$|^api$|^dev$|^plugin$|^plugins$|^download$|^baixar$|^comprar$|^buy$|^store$|^spigot$|^bukkit$|^sponge$|^www$|^off$|^promocao$|^wss$|^blog$|^noticias$|^mail$|^server$|^template$|^templates$|^app$|^play$|^ipn$|^auth$|^oauth$|^ping$|^status$|^go$|^oferta$|^login$|^account$|^panel$|^painel$|^conta$|^eu$|^minecraft$|^servidor$|^events$|^msdk$|^oficial$|^official$|^brasil$|^brazil$|^test$|^lab$|^pt$|^br$|^us$|^gg$|^v1$|^v2$|^v3$|^minemarket$|^cubemarket$|^cubeshop$|^exemplo$|^example$|^xvideos$|^redtube$|^porno$|^link$|^www1$|^www2$|^www3$|^www4$|^apelido$|^nickname$|^uuid$|^top$|^gratis$|^free$|^license$|^okay$|^about$|^sobre$|^senha$|^password$|^forum$|^wiki$|^doc$|^documentation$|^documentacao$|^space$|^storage$|^backup$|^load$|^loading$|^web$|^tutorial$|^minhaconta$|^mine-shop$|^mineshop2$|^ms$|^online$|^offline$/gi.test(params.newAddress.split('.')[0])
        } else {
          return response.status(422).send({
            error: {
              newAddress: 'O subdomínio que você informou é inválido. Ele deve conter, no mínimo, 4 caracteres e suporta apenas caracteres alfanuméricos.'
            }
          })
        }
      } else if (/[a-zA-Z0-9][a-zA-Z0-9-]{1,61}[a-zA-Z0-9](?:\.[a-zA-Z]{2,})+/.test(params.newAddress)) {
        newAddressIsValid = true
      }

      if (!newAddressIsValid) {
        return response.status(422).send({
          error: { newAddress: 'Esse endereço não é um subdomínio ou domínio válido.' }
        })
      }

      const newAddressInUse = await Store
      .query()
      .where('address', params.newAddress)
      .first()

      if (newAddressInUse) {
        return response.status(422).send({
          error: { newAddress: 'Esse endereço já está sendo utilizado. Entre em contato com o suporte se você for o verdadeiro dono deste domínio.' }
        })
      }

      const store = await Store.find(request.user.manage_store)

      store.merge({
        address: params.newAddress
      })

      await store.save()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async updateGateways ({ request, response }) {
    const params = request.all()

    if (!_.isUndefined(params.paypal)) {
      const basic = {
        clientId: !_.isUndefined(params.paypal.clientId)
        ? _.trim(params.paypal.clientId)
        : '',

        clientSecret: !_.isUndefined(params.paypal.clientSecret)
        ? _.trim(params.paypal.clientSecret)
        : '',

        active: _.isBoolean(params.paypal.active)
        ? params.paypal.active
        : false
      }

      const error = {}

      if (basic.active === true) {
        if (!basic.clientId.length) {
          error['clientId'] = 'Este campo é necessário para habilitar este método de pagamento'
        }

        if (!basic.clientSecret.length) {
          error['clientSecret'] = 'Este campo é necessário para habilitar este método de pagamento'
        }
      }

      if (_.gte(basic.clientId.length, 255)) {
        error['clientId'] = 'Este campo excedeu o limite de 255 caracteres permitidos.'
      }

      if (_.gte(basic.clientSecret.length, 255)) {
        error['clientSecret'] = 'Este campo excedeu o limite de 255 caracteres permitidos.'
      }

      if (!_.isEmpty(error)) {
        return response.status(422).send({ error })
      }

      const gateways = await StorePaymentGateway
      .query()
      .where('store_id', request.user.manage_store)
      .first()

      gateways.merge({
        paypal: JSON.stringify({ basic: basic })
      })

      await gateways.save()
    }

    if (!_.isUndefined(params.mercadopago)) {
      const basic = {
        clientId: !_.isUndefined(params.mercadopago.clientId)
        ? _.trim(params.mercadopago.clientId)
        : '',

        clientSecret: !_.isUndefined(params.mercadopago.clientSecret)
        ? _.trim(params.mercadopago.clientSecret)
        : '',

        active: _.isBoolean(params.mercadopago.active)
        ? params.mercadopago.active
        : false
      }

      const error = {}

      if (basic.active === true) {
        if (!basic.clientId.length) {
          error['clientId'] = 'Este campo é necessário para habilitar este método de pagamento'
        }

        if (!basic.clientSecret.length) {
          error['clientSecret'] = 'Este campo é necessário para habilitar este método de pagamento'
        }
      }

      if (_.gte(basic.clientId.length, 255)) {
        error['clientId'] = 'Este campo excedeu o limite de 255 caracteres permitidos.'
      }

      if (_.gte(basic.clientSecret.length, 255)) {
        error['clientSecret'] = 'Este campo excedeu o limite de 255 caracteres permitidos.'
      }

      if (!_.isEmpty(error)) {
        return response.status(422).send({ error })
      }

      const gateways = await StorePaymentGateway
      .query()
      .where('store_id', request.user.manage_store)
      .first()

      gateways.merge({
        mercadopago: JSON.stringify({ basic: basic })
      })

      await gateways.save()
    }

    if (!_.isUndefined(params.pagseguro)) {
      const basic = {
        email: !_.isUndefined(params.pagseguro.email)
        ? _.trim(params.pagseguro.email)
        : '',

        token: !_.isUndefined(params.pagseguro.token)
        ? _.trim(params.pagseguro.token)
        : '',

        active: _.isBoolean(params.pagseguro.active)
        ? params.pagseguro.active
        : false
      }

      const error = {}

      if (basic.active === true) {
        if (!basic.email.length) {
          error['email'] = 'Este campo é necessário para habilitar este método de pagamento'
        }

        if (!basic.token.length) {
          error['token'] = 'Este campo é necessário para habilitar este método de pagamento'
        }
      }

      if (_.gte(basic.email.length, 255)) {
        error['email'] = 'Este campo excedeu o limite de 255 caracteres permitidos.'
      }

      if (_.gte(basic.token.length, 255)) {
        error['token'] = 'Este campo excedeu o limite de 255 caracteres permitidos.'
      }

      if (!_.isEmpty(error)) {
        return response.status(422).send({ error })
      }

      const gateways = await StorePaymentGateway
      .query()
      .where('store_id', request.user.manage_store)
      .first()

      gateways.merge({
        pagseguro: JSON.stringify({ basic: basic })
      })

      await gateways.save()
    }
  }

  async updateLegal ({ request, response }) {
    const sanitizeRules = {
      terms: 'trim',
      refundPolicy: 'trim'
    }

    const rules = {
      terms: 'string',
      refundPolicy: 'string'
    }

    const messages = {}

    const params = sanitize(request.only(['terms', 'refundPolicy']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      const settings = await StoreSetting
      .query()
      .where('store_id', request.user.manage_store)
      .first()

      settings.merge({
        terms: params.terms ? params.terms.replace(/\s+/g, ' ') : params.terms,
        refund_policy: params.refundPolicy ? params.refundPolicy.replace(/\s+/g, ' ') : params.refundPolicy
      })

      await settings.save()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }
}

module.exports = StoreSettingController
