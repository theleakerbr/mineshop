'use strict'

const { validateAll, sanitize, rule } = use('Validator')
const uuid = use('uuid')

const StoreServer = use('App/Models/StoreServer')

class StoreServerController {
  async show ({ request, view }) {
    let servers = await StoreServer
    .query()
    .where('store_id', request.user.manage_store)
    .orderBy('created_at', 'desc')
    .fetch()

    try {
      servers = servers.toJSON()
    } catch (err) {}

    return view.render('panel.store.servers.servers', {
      servers: servers
    })
  }

  async create ({ request, response }) {
    const sanitizeRules = {
      name: 'trim'
    }

    const rules = {
      name: 'required|min:3|max:15',
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'min': 'Esse campo precisa ter no mínimo {{ argument.0 }} caracteres',
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres'
    }

    const params = sanitize(request.only(['name']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      params.name = params.name.replace(/\s+/g, ' ')

      let numServers = 0

      let servers = await StoreServer
      .query()
      .where('store_id', request.user.manage_store)
      .fetch()

      try {
        servers = servers.toJSON()
      } catch (err) {}

      for (let i = 0; i < servers.length; i++) {
        numServers++
      }

      if (numServers >= 10) {
        return response.status(403).send({
          error: { other: 'Desculpe, mas você atingiu o número máximo de servidores permitidos para esta loja.' }
        })
      }

      await StoreServer.create({
        store_id: request.user.manage_store,
        token: uuid.v4(),
        name: params.name,
        last_connection: null
      })
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async update ({ request, response }) {
    const sanitizeRules = {
      id: 'to_int',
      token: 'to_boolean',
      name: 'trim'
    }

    const rules = {
      id: 'required',
      token: 'boolean',
      name: 'min:3|max:15',
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'min': 'Esse campo precisa ter no mínimo {{ argument.0 }} caracteres.',
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres.',
      'boolean': 'Esse campo precisa ser do tipo boleano.'
    }

    const params = sanitize(request.only(['id', 'token', 'name']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      const server = await StoreServer
      .query()
      .where('id', params.id)
      .andWhere('store_id', request.user.manage_store)
      .first()

      if (params.token) {
        server.merge({
          token: uuid.v4()
        })
      }

      if (params.name) {
        params.name = params.name.replace(/\s+/g, ' ')

        server.merge({
          name: params.name
        })
      }

      await server.save()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async delete ({ request, response }) {
    const sanitizeRules = {
      id: 'to_int'
    }

    const rules = {
      id: 'required'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.'
    }

    const params = sanitize(request.only(['id']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      const server = await StoreServer
      .query()
      .where('store_id', request.user.manage_store)
      .andWhere('id', params.id)
      .first()

      if (!server) {
        return response.status(422).send({
          error: { id: 'Oops! Parece que o servidor que você está tentando excluir não existe mais.' }
        })
      }

      await server.delete()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }
}

module.exports = StoreServerController
