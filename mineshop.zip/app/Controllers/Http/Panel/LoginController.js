'use strict'

const { validateAll, sanitize } = use('Validator')
const Hash = use('Hash')
const uuid = use('uuid')
const Route = use('Route')

const User = use('App/Models/User')
const UserSession = use('App/Models/UserSession')

class LoginController {
  async show ({ request, view }) {
    return view.render('panel.login', {
      returnUrl: request.input('r', Route.url('panel.dashboard.show'))
    })
  }

  async createUserSession ({ request, response, session }) {
    const sanitizeRules = {
      email: 'trim|normalize_email',
      password: 'trim'
    }

    const rules = {
      email: 'required|email',
      password: 'required'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'email': 'O endereço de email informado é inválido.'
    }

    const params = sanitize(request.only(['email', 'password']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      let user = await User
      .query()
      .where('email', params.email)
      .first()

      try {
        user = user.toJSON()
      } catch (err) {}

      if (user) {
        const isSame = await Hash.verify(params.password, user.password)
        if (isSame) {
          if (user.group !== 'BANNED') {
            const userSession = new UserSession()

            userSession.fill({
              user_id: user.id,
              token: uuid.v4(),
              active: true,
              remote_addr: request.ip(),
              user_agent: request.header('User-Agent')
            })

            await userSession.save()

            session.put('userSessionToken', userSession.$attributes.token)
          } else {
            response.status(422).send({
              error: {
                email: 'Esse usuário foi banido do sistema.'
              }
            })
          }
        } else {
          response.status(422).send({
            error: {
              password: 'Senha incorreta. Tente novamente ou redefina sua senha.'
            }
          })
        }
      } else {
        response.status(422).send({
          error: {
            email: 'Esse e-mail não percente a nenhum usuário cadastrado'
          }
        })
      }
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }
}

module.exports = LoginController
