'use strict'

const { validateAll, sanitize, rule } = use('Validator')

const StoreNew = use('App/Models/StoreNew')

class StoreNewsController {
  async show ({ request, view }) {
    let news = await StoreNew
    .query()
    .where('store_id', request.user.manage_store)
    .orderBy('created_at', 'desc')
    .fetch()

    try {
      news = news.toJSON()
    } catch (err) {}

    return view.render('panel.store.news.news', {
      allNews: news
    })
  }

  async showNewNews ({ view }) {
    return view.render('panel.store.news.new')
  }

  async showEditNews ({ request, view, params }) {
    let news = await StoreNew
    .query()
    .where('id', params.id)
    .andWhere('store_id', request.user.manage_store)
    .first()

    try {
      news = news.toJSON()
    } catch (err) {}

    return view.render('panel.store.news.edit', {
      news: news
    })
  }

  async create ({ request, response }) {
    const sanitizeRules = {
      title: 'trim',
      body: 'trim'
    }

    const rules = {
      title: 'required|min:3|max:120',
      body: 'required'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'min': 'Esse campo precisa ter no mínimo {{ argument.0 }} caracteres',
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres'
    }

    const params = sanitize(request.only(['title', 'body']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      await StoreNew.create({
        store_id: request.user.manage_store,
        title: params.title,
        body: params.body,
        views: 0,
        broadcast: false,
        status: 'PUBLISHED',
        scheduled_to: null
      })
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async update ({ request, response }) {
    const sanitizeRules = {
      id: 'to_int'
    }

    const rules = {
      id: 'required|integer'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'integer': 'Este campo deve ser um numeral.'
    }

    const params = sanitize(request.only(['id']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      const news = await StoreNew
      .query()
      .where('store_id', request.user.manage_store)
      .andWhere('id', params.id)
      .first()

      if (!news) {
        return response.status(422).send({
          error: { id: 'Oops! Parece que esta notícia não existe mais.' }
        })
      }

      news.merge({
        broadcast: news.broadcast ? false : true
      })

      await news.save()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async editUpdate ({ request, params }) {
    const sanitizeRules = {
      title: 'trim',
      body: 'trim'
    }

    const rules = {
      title: 'required|min:3|max:120',
      body: 'required'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'min': 'Esse campo precisa ter no mínimo {{ argument.0 }} caracteres',
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres'
    }

    const paramsValidator = sanitize(request.only(['title', 'body']), sanitizeRules)
    const validation = await validateAll(paramsValidator, rules, messages)

    if (!validation.fails()) {
      const news = await StoreNew
      .query()
      .where('id', params.id)
      .andWhere('store_id', request.user.manage_store)
      .first()

      if (!news) {
        return response.status(422).send({
          error: {
            newsId: 'O id informado é inválido.'
          }
        })
      }

      news.merge({
        title: paramsValidator.title,
        body: paramsValidator.body
      })

      await news.save()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }

  async delete ({ request, response }) {
    const sanitizeRules = {
      id: 'to_int'
    }

    const rules = {
      id: 'required|integer'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'integer': 'Este campo deve ser um numeral.'
    }

    const params = sanitize(request.only(['id']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      const news = await StoreNew
      .query()
      .where('store_id', request.user.manage_store)
      .andWhere('id', params.id)
      .first()

      if (!news) {
        return response.status(422).send({
          error: {
            id: 'Parece que a notícia que você está tentando excluir não existe mais.'
          }
        })
      }

      await news.delete()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }
}

module.exports = StoreNewsController
