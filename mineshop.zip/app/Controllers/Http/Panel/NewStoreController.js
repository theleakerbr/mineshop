'use strict'

const { validateAll, sanitize, rule } = use('Validator')

const Database = use('Database')

const Store = use('App/Models/Store')
const StoreSetting = use('App/Models/StoreSetting')
const StorePaymentGateway = use('App/Models/StorePaymentGateway')
const User = use('App/Models/User')
const UserAcl = use('App/Models/UserAcl')
const Statistic = use('App/Models/Statistic')

class NewStoreController {
  async show ({ view }) {
    return view.render('panel.stores.new')
  }

  async create ({ request, response }) {
    const sanitizeRules = {
      name: 'trim',
      address: 'trim'
    }

    const rules = {
      name: 'required|max:20',
      address: [
        rule('required'),
        rule('min', 4),
        rule('max', 25),
        rule('regex', /^[a-zA-Z0-9]*$/)
      ],
      sandbox: 'boolean'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'min': 'Esse campo precisa ter no mínimo {{ argument.0 }} caracteres.',
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres.',
      'boolean': 'Esse campo deve ser do tipo boleano.',
      'regex': 'Esse campo suporta apenas caracteres alfanuméricos.'
    }

    const params = sanitize(request.only(['name', 'address', 'sandbox']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      params.name = params.name.replace(/\s+/g, ' ')
      params.address = params.address.toLowerCase()
  
      if (/^ms2$|^mineshop$|^loja$|^lojas$|^black$|^api$|^dev$|^plugin$|^plugins$|^download$|^baixar$|^comprar$|^buy$|^store$|^spigot$|^bukkit$|^sponge$|^www$|^off$|^promocao$|^wss$|^blog$|^noticias$|^mail$|^server$|^template$|^templates$|^app$|^play$|^ipn$|^auth$|^oauth$|^ping$|^status$|^go$|^oferta$|^login$|^account$|^panel$|^painel$|^conta$|^eu$|^minecraft$|^servidor$|^events$|^msdk$|^oficial$|^official$|^brasil$|^brazil$|^test$|^lab$|^pt$|^br$|^us$|^gg$|^v1$|^v2$|^v3$|^minemarket$|^cubemarket$|^cubeshop$|^exemplo$|^example$|^xvideos$|^redtube$|^porno$|^link$|^www1$|^www2$|^www3$|^www4$|^apelido$|^nickname$|^uuid$|^top$|^gratis$|^free$|^license$|^okay$|^about$|^sobre$|^senha$|^password$|^forum$|^wiki$|^doc$|^documentation$|^documentacao$|^space$|^storage$|^backup$|^load$|^loading$|^web$|^tutorial$|^minhaconta$|^mine-shop$|^mineshop2$|^ms$|^online$|^offline$/gi.test(params.address)) {
        return response.status(422).send({
          error: { address: 'Este subdomínio não pode ser utilizado.' }
        })
      }

      let store = await Store
      .query()
      .where('address', `${params.address}.mineshop.com.br`)
      .first()

      if (store) {
        return response.status(422).send({
          error: { address: 'Esse endereço já está sendo utilizado por outra loja.' }
        })
      }

      let acls = await UserAcl
      .query()
      .setVisible(['store_id'])
      .where('user_id', request.user.id)
      .andWhere('owner', true)
      .fetch()

      try {
        acls = acls.toJSON()
      } catch (err) {
        acls = []
      }

      let numSandbox = 0
      let numPending = 0

      for (let i = 0; i < acls.length; i++) {
        let tmp = await Store.find(acls[i].store_id)

        try {
          tmp = tmp.toJSON()
        } catch (err) {}

        if (tmp) {
          if (tmp.plan === 'PROFISSIONAL') {
            if (tmp.status === 'PENDING') {
              numPending++
            }
          } else if (tmp.plan === 'SANDBOX') {
            numSandbox++
          }
        }
      }

      if (params.sandbox) {
        if (numSandbox >= 1) {
          return response.status(403).send({
            error: { other: 'Desculpe, mas você atingiu o limite permitido de lojas em modo sandbox na sua conta.' }
          })
        }
      } else {
        if (numPending >= 5) {
          return response.status(403).send({
            error: { other: 'Desculpe, mas você tem muitas lojas pendentes na sua conta. Pague ou exclua algumas delas para poder criar novas.' }
          })
        }
      }

      const trx = await Database.beginTransaction()

      try {
        store = new Store()

        store.fill({
          address: `${params.address}.mineshop.com.br`,
          days_remaining: 0,
          plan: params.sandbox ? 'SANDBOX' : 'PROFISSIONAL',
          status: params.sandbox ? 'ACTIVE' : 'PENDING',
          custom_price: null
        })

        await store.save(trx)

        await StoreSetting.create({
          store_id: store.$attributes.id,
          name: params.name,
          slogan: 'Hoje é um lindo dia para fazer sonhos acontecerem.',
          favicon: null,
          logotipo: null,
          analytics: null,
          sliders: JSON.stringify(['/official/img/firstslider.png']),
          terms: null,
          refund_policy: null,
          colors: null,
          styles: null,
          scripts: null,
          template: 'DEFAULT'
        }, trx)

        await StorePaymentGateway.create({
          store_id: store.$attributes.id,
          paypal: null,
          mercadopago: null,
          pagseguro: null
        }, trx)

        await UserAcl.create({
          store_id: store.$attributes.id,
          user_id: request.user.id,
          owner: true
        }, trx)

        const statistic = await Statistic
        .query()
        .where('key', 'instancedStores')
        .first()

        statistic.merge({
          value: parseInt(statistic.value, 10) + 1
        })

        await statistic.save(trx)

        const user = await User.find(request.user.id)

        user.merge({
          manage_store: store.$attributes.id
        })

        await user.save(trx)

        await trx.commit()
      } catch (err) {
        await trx.rollback()
        throw new Error(err)
      }
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }
}

module.exports = NewStoreController
