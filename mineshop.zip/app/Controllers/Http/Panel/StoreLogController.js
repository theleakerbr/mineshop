'use strict'

class StoreLogController {
  async show ({ view }) {
    return view.render('panel.store.logs.logs')
  }
}

module.exports = StoreLogController
