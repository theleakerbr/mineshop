'use strict'

const _ = use('lodash')
const Env = use('Env')
const mercadopago = use('mercadopago')
const uuid = use('uuid')
const axios = use('axios')

const Store = use('App/Models/Store')
const UserInvoice = use('App/Models/UserInvoice')

mercadopago.configure({
  access_token: Env.get('MERCADOPAGO_ACCESS_TOKEN')
})

class StoreLicenseController {
  async show ({ request, view }) {
    let store = await Store.find(request.user.manage_store)
    store = store.toJSON()

    let price = parseFloat(Env.get('PLAN_PROFISSIONAL'))

    if (store.custom_price) {
      price = store.custom_price
    }

    return view.render('panel.store.license.license', {
      user: request.user,
      store: store,
      plans: {
        profissional: {
          monthly: price,
          bimonthly: (price - (price * 0.0353)) * 2,
          quarterly: (price - (price * 0.0719)) * 3
        }
      }
    })
  }

  async createBankSlip ({ request, response }) {
    let { recurrence, firstName, surname, document } = _.mapValues(request.all(), (value) => {
      if (_.isString(value)) {
        value = _.trim(value).replace(/\s\s+/g, ' ')
      }

      return value
    })

    if (!recurrence.match(/^MONTHLY$|^BIMONTHLY$|^QUARTERLY$/i)) {
      return response.status(400).send({
        error: {
          other: 'Informe um período de recorrência válido.'
        }
      })
    }

    if (_.isEmpty(firstName)) {
      return response.status(422).send({
        error: {
          firstName: 'Você deve informar um nome.'
        }
      })
    }

    if (_.isEmpty(surname)) {
      return response.status(422).send({
        error: {
          surname: 'Você deve informar um sobrenome.'
        }
      })
    }

    let store = await Store.find(request.user.manage_store)
    store = store.toJSON()

    let days = 30
    let price = parseFloat(Env.get('PLAN_PROFISSIONAL'))

    if (store.custom_price) {
      price = store.custom_price
    }

    if (recurrence.match(/^BIMONTHLY$/i)) {
      days = days * 2
      price = (price - (price * 0.0353)) * 2
    }

    if (recurrence.match(/^QUARTERLY$/i)) {
      days = days * 3
      price = (price - (price * 0.0719)) * 3
    }

    price = parseFloat(price.toFixed(2))
    const externalReference = uuid.v4()

    try {
      const res = await mercadopago.payment.create({
        transaction_amount: price,
        payment_method_id: 'bolbradesco',
        notification_url: `https://api.mineshop.com.br/ipn/v1/mercadopago`,
        external_reference: externalReference,
        payer: {
          first_name: firstName,
          last_name: surname,
          email: request.user.email,
          identification: { type: 'cpf', number: document }
        }
      })

      await UserInvoice.create({
        uid: uuid.v4(),
        user_id: request.user.id,
        subtotal: price,
        total: price,
        payment_method: 'BANK_SLIP',
        status: 'AWAITING_PAYMENT',
        dispatched: false,
        reference: externalReference,
        metadata: `STORE:${store.id}:LICENSE:PROFISSIONAL:INCREMENT:${days}`,
        history: null,
        remote_addr: request.ip(),
        user_agent: request.header('User-Agent'),
        context: null
      })

      if (!_.has(res, 'response.transaction_details.external_resource_url')) {
        throw new Error('Não foi possível obter o endereço do boleto')
      }

      return response.status(200).send({
        bankSlipUrl: res.response.transaction_details.external_resource_url
      })
    } catch (err) {
      console.log(err)
    }
  }

  async createPicpay ({ request, response }) {
    let { recurrence, firstName, surname, document, phone } = _.mapValues(request.all(), (value) => {
      if (_.isString(value)) {
        value = _.trim(value).replace(/\s\s+/g, ' ')
      }

      return value
    })

    if (!recurrence.match(/^MONTHLY$|^BIMONTHLY$|^QUARTERLY$/i)) {
      return response.status(400).send({
        error: {
          other: 'Informe um período de recorrência válido.'
        }
      })
    }

    if (_.isEmpty(firstName)) {
      return response.status(422).send({
        error: {
          firstName: 'Você deve informar um nome.'
        }
      })
    }

    if (_.isEmpty(surname)) {
      return response.status(422).send({
        error: {
          surname: 'Você deve informar um sobrenome.'
        }
      })
    }

    if (_.isEmpty(phone)) {
      return response.status(422).send({
        error: {
          surname: 'Você deve informar um telefone.'
        }
      })
    }

    let store = await Store.find(request.user.manage_store)
    store = store.toJSON()

    let days = 30
    let price = parseFloat(Env.get('PLAN_PROFISSIONAL'))

    if (store.custom_price) {
      price = store.custom_price
    }

    if (recurrence.match(/^BIMONTHLY$/i)) {
      days = days * 2
      price = (price - (price * 0.0353)) * 2
    }

    if (recurrence.match(/^QUARTERLY$/i)) {
      days = days * 3
      price = (price - (price * 0.0719)) * 3
    }

    price = parseFloat(price.toFixed(2))
    const externalReference = uuid.v4()

    try {
      const res = await axios.post('https://appws.picpay.com/ecommerce/public/payments', {
        referenceId: externalReference,
        callbackUrl: 'https://api.mineshop.com.br/ipn/v1/picpay',
        value: price,
        buyer: {
          firstName: firstName,
          lastName: surname,
          document: document,
          email: request.user.email,
          phone: phone
        }
      }, {
        headers: { 'x-picpay-token': Env.get('PICPAY_TOKEN'), 'Accept-Encoding': 'gzip' }
      })

      await UserInvoice.create({
        uid: uuid.v4(),
        user_id: request.user.id,
        subtotal: price,
        total: price,
        payment_method: 'PICPAY',
        status: 'AWAITING_PAYMENT',
        dispatched: false,
        reference: externalReference,
        metadata: `STORE:${store.id}:LICENSE:PROFISSIONAL:INCREMENT:${days}`,
        history: null,
        remote_addr: request.ip(),
        user_agent: request.header('User-Agent'),
        context: null
      })

      return response.status(200).send({
        qrcode: res.data.qrcode.base64
      })
    } catch (err) {
      console.log(err)
    }
  }
}

module.exports = StoreLicenseController
