'use strict'

const Route = use('Route')

const UserSession = use('App/Models/UserSession')

class LogoutController {
  async show ({ view }) {
    return view.render('panel.logout')
  }

  async closeSession ({ request, session }) {
    const token = session.get('userSessionToken', false)

    if (token) {
      const userSession = await UserSession
      .query()
      .where('user_id', request.user.id)
      .andWhere('token', token)
      .first()

      if (userSession) {
        userSession.merge({
          active: false
        })

        await userSession.save()
      }
    }

    session.forget('userSessionToken')
  }
}

module.exports = LogoutController
