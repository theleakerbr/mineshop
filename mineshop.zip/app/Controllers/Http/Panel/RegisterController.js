'use strict'

const { validateAll, sanitize } = use('Validator')

const Route = use('Route')
const Env = use('Env')

const User = use('App/Models/User')

const allowRegistrations = Env.get('ALLOW_REGISTRATIONS').toLowerCase()

class RegisterController {
  async show ({ view, params }) {
    return view.render('panel.register', {
      email: params.email || null
    })
  }

  async createUser ({ request, response }) {
    if (allowRegistrations !== 'yes') {
      return response.status(423).send({
        error: {
          other: 'O sistema de cadastro de usuários foi temporariamente desabilitado.'
        }
      })
    }

    const sanitizeRules = {
      email: 'trim|normalize_email',
      password: 'trim'
    }

    const rules = {
      email: 'required|email',
      password: 'required|min:6|max:255'
    }

    const messages = {
      'required': 'Você deve preencher esse campo.',
      'email': 'O endereço de email informado é inválido.',
      'min': 'Esse campo precisa ter no mínimo {{ argument.0 }} caracteres',
      'max': 'Esse campo não pode ter mais de {{ argument.0 }} caracteres'
    }

    const params = sanitize(request.only(['email', 'password']), sanitizeRules)
    const validation = await validateAll(params, rules, messages)

    if (!validation.fails()) {
      let user = await User
      .query()
      .where('email', params.email)
      .first()

      try {
        user = user.toJSON()
      } catch (err) {}

      if (user) {
        return response.status(422).send({
          error: {
            email: 'Esse e-mail já está sendo utilizado'
          }
        })
      }

      user = new User()

      user.fill({
        email: params.email,
        password: params.password,
        group: 'CLIENT',
        manage_store: null,
        first_name: null,
        surname: null,
        phone: null,
        discord_tag: null,
        is_verified: false,
        tfa: null,
        referral: null,
        remote_addr: request.ip(),
        user_agent: request.header('User-Agent')
      })

      return await user.save()
    } else {
      const error = {}

      for (let i = 0; i < validation.messages().length; i++) {
        error[validation.messages()[i].field] = validation.messages()[i].message
      }

      response.status(422).send({ error })
    }
  }
}

module.exports = RegisterController
