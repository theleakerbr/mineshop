'use strict'

const _ = use('lodash')
const StoreSetting = use('App/Models/StoreSetting')

class StoreAppearanceController {
  async show ({ request, view }) {
    let settings = await StoreSetting
    .query()
    .where('store_id', request.user.manage_store)
    .first()

    settings = settings.toJSON()
    settings.colors = JSON.parse(settings.colors)

    return view.render('panel.store.appearance.appearance', {
      settings: settings
    })
  }

  async showJavaScriptPage ({ request, view }) {
    let settings = await StoreSetting
    .query()
    .where('store_id', request.user.manage_store)
    .first()

    settings = settings.toJSON()
    settings.scripts = settings.scripts
    ? settings.scripts.replace(/\\/gi, '\\\\').replace(/\r/gi, '\\r').replace(/\n/gi, '\\n').replace(/'/gi, "\\'").replace(/"/gi, '\\"').replace(/<\/script>/gi, '<\\/script>')
    : settings.scripts

    return view.render('panel.store.appearance.javascript', {
      settings: settings
    })
  }

  async showCssPage ({ request, view }) {
    let settings = await StoreSetting
    .query()
    .where('store_id', request.user.manage_store)
    .first()

    settings = settings.toJSON()
    settings.styles = settings.styles
    ? settings.styles.replace(/\\/gi, '\\\\').replace(/\r/gi, '\\r').replace(/\n/gi, '\\n').replace(/'/gi, "\\'").replace(/"/gi, '\\"')
    : settings.styles

    return view.render('panel.store.appearance.css', {
      settings: settings
    })
  }

  async update ({ request }) {
    const { logotipo, favicon, sliders } = _.mapValues(request.all(), (value) => {
      if (_.isString(value)) {
        return _.trim(value)
      }

      return value
    })

    const settings = await StoreSetting
    .query()
    .where('store_id', request.user.manage_store)
    .first()

    settings.merge({
      logotipo: !_.isUndefined(logotipo) ? logotipo : settings.logotipo,
      favicon: !_.isUndefined(favicon) ? favicon : settings.favicon,
      sliders: !_.isUndefined(sliders) ? JSON.stringify(sliders) : settings.sliders
    })

    await settings.save()
  }

  async updateJavaScript ({ request }) {
    const { scripts } = request.all()

    const settings = await StoreSetting
    .query()
    .where('store_id', request.user.manage_store)
    .first()

    settings.merge({
      scripts: scripts ? scripts : null
    })

    if (scripts) {
      if ((scripts.match(/<script[\s\S]*?>/gi) || []).length !== (scripts.match(/<\/script>/gi) || []).length) {
        settings.merge({
          scripts: scripts.replace(/<script[\s\S]*?>|<\/script>/gi, '') || null
        })
      }
    }

    await settings.save()
  }

  async updateCss ({ request }) {
    const { styles } = request.all()

    const settings = await StoreSetting
    .query()
    .where('store_id', request.user.manage_store)
    .first()

    settings.merge({
      styles: styles ? styles.replace(/<style>|<\/style>/gi, '') : null
    })

    await settings.save()
  }
}

module.exports = StoreAppearanceController
