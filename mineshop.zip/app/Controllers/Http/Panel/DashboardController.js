'use strict'

const Route = use('Route')

class DashboardController {
  async show ({ response }) {
    response.redirect(Route.url('panel.stores.show'))
  }
}

module.exports = DashboardController
