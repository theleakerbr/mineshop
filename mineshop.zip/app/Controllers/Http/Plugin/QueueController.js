'use strict'

const _ = use('lodash')
const StoreServerQueueItem = use('App/Models/StoreServerQueueItem')

class QueueController {
  async listAllQueues ({ request, params }) {
    const { nickname } = _.mapValues(params, (value) => {
      if (_.isString(value)) {
        return _.trim(decodeURI(value))
      }

      return value
    })

    let queue = null

    if (nickname) {
      queue = await StoreServerQueueItem
      .query()
      .setVisible(['uuid', 'nickname', 'command', 'slots_needed', 'type', 'status'])
      .where('store_server_id', request.server.id)
      .andWhere('nickname', params.nickname)
      .andWhere('status', 'FORWARDED')
      .fetch()
    } else {
      queue = await StoreServerQueueItem
      .query()
      .setVisible(['uuid', 'nickname', 'command', 'slots_needed', 'type', 'status'])
      .where('store_server_id', request.server.id)
      .andWhere('status', 'FORWARDED')
      .fetch()
    }

    queue = !_.isNull(queue) && _.isFunction(queue.toJSON) ? queue.toJSON() : queue

    for (let i = 0; i < queue.length; i++) {
      queue[i].slotsNeeded = queue[i].slots_needed
      delete queue[i].slots_needed
    }

    return queue
  }

  async updateQueueByNicknameAndUuid ({ request, response, params }) {
    const { nickname, uuid } = _.mapValues(params, (value) => {
      return _.trim(decodeURI(value))
    })

    if (!nickname) {
      return response.status(422).send({
        error: { nickname: 'este parâmetro é obrigatório' }
      })
    }

    if (!uuid) {
      return response.status(422).send({
        error: { uuid: 'este parâmetro é obrigatório' }
      })
    }

    const queueItem = await StoreServerQueueItem
    .query()
    .where('store_server_id', request.server.id)
    .andWhere('uuid', uuid)
    .andWhere('nickname', nickname)
    .andWhere('status', 'FORWARDED')
    .first()

    if (!queueItem) {
      return response.status(422).send({
        error: { other: 'este apelido e uuid não correspondem a nenhum item pendente na fila' }
      })
    }

    queueItem.merge({
      status: 'DELIVERED'
    })

    await queueItem.save()
  }
}

module.exports = QueueController
