'use strict'

const Database = use('Database')
const Env = use('Env')

const Statistic = use('App/Models/Statistic')
const UserFeedback = use('App/Models/UserFeedback')

class WebsiteController {
  async show ({ view }) {
    let instancedStores = await Statistic
    .query()
    .setVisible(['value'])
    .where('key', 'instancedStores')
    .first()

    try {
      instancedStores = instancedStores.toJSON()
      instancedStores = instancedStores.value
    } catch (err) {}

    let approvedPayments = await Statistic
    .query()
    .setVisible(['value'])
    .where('key', 'approvedPayments')
    .first()

    try {
      approvedPayments = approvedPayments.toJSON()
      approvedPayments = approvedPayments.value
    } catch (err) {}

    let reputation = await UserFeedback
    .query()
    .setVisible(['first_name', 'surname', 'message', 'note'])
    .where('status', 'ALREADY_READ')
    .orWhere('status', 'PUBLISHED')

    if (reputation.length >= 1) {
      let tmp = 0
      for (let i = 0; i < reputation.length; i++) {
        tmp = tmp + reputation[i].note
      }

      reputation = tmp / reputation.length
    } else {
      reputation = 9.6
    }

    let feedback = await Database.raw("SELECT * FROM `user_feedbacks` WHERE `status` = 'PUBLISHED' ORDER BY RAND() LIMIT 1")

    if (typeof feedback[0][0] !== 'undefined') {
      let author = 'Sem nome'
      let message = feedback[0][0].message

      if (feedback[0][0].first_name && feedback[0][0].surname) {
        author = `${feedback[0][0].first_name} ${feedback[0][0].surname}`
      }

      feedback = { author: author, message: message }
    } else {
      feedback = {
        author: 'Bot',
        message: 'Desculpe! Nossos parceiros ainda não tiveram tempo de deixar uma linda mensagem aqui.'
      }
    }

    const plans = {
      sandbox: Env.get('PLAN_SANDBOX').replace('.', ','),
      profissional: Env.get('PLAN_PROFISSIONAL').replace('.', ',')
    }

    return view.render('website.index', {
      instancedStores: instancedStores,
      approvedPayments: approvedPayments,
      reputation: reputation.toString().replace('.', ','),
      feedback: feedback,
      plans: plans
    })
  }
}

module.exports = WebsiteController
