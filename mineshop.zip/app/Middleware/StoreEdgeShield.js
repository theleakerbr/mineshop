'use strict'

const Route = use('Route')
const _ = use('lodash')

const route = (name, params) => {
  return Route.url(`store.${name}`, params || {})
}

class StoreEdgeShield {
  async handle ({ request, view }, next) {
    const env = _.cloneDeep(request.store.env)
    const cart = _.cloneDeep(request.store.cart)

    delete env.template
    delete env.custom_template
    delete cart.id

    view.share({
      _: null,
      toJSON: null,
      batch: null,
      el: null,
      range: null,
      request: null,
      route: route,
      env: env,
      cart: cart
    })

    await next()
  }
}

module.exports = StoreEdgeShield
