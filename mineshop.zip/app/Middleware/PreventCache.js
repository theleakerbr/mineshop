'use strict'

class PreventCache {
  async handle ({ response }, next) {
    response.header('Cache-Control', 'private, no-cache, no-store, must-revalidate')
    response.header('Expires', '-1')
    response.header('Pragma', 'no-cache')

    await next()
  }
}

module.exports = PreventCache
