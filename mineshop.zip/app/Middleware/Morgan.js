'use strict'

const _ = use('lodash')
const Logger = use('Logger')

class Morgan {
  async handle ({ request }, next) {
    let ip = _.padStart(request.ip(), 15, '.')
    let method = _.padStart(request.method(), 6, '.')

    Logger.info(
      `${ip} > [${method}] ${request.header('Host')}${request.originalUrl()}`
    )

    await next()
  }
}

module.exports = Morgan
