'use strict'

const Drive = use('Drive')

class StoreTemplate {
  async handle ({ request }, next) {
    const files = [
      'layout.edge', 'index.edge', 'allNews.edge', 'news.edge',
      'orders.edge', 'cart.edge'
    ]

    request.store.template = {}

    if (request.store.env.template === 'CUSTOM') {
      //TODO: Refazer essa sessão para se adequar ao novo sistema de templates antes de habilitar a edição de templates

      const template = request.store.env.custom_template
      const folder = `store/custom/${template}`
      const folderExists = await Drive.disk('views').exists(folder)

      if (!folderExists) {
        for (let i = 0; i < files.length; i++) {
          const fileExists = await Drive.disk('views').exists(`${folder}/${files[i]}`)
          if (!fileExists) {
            await Drive.disk('views').put(
              `${folder}/${files[i]}`,
              (await Drive.disk('spaces').getObject(`edge/${template}/${files[i]}`)).Body
            )
          }
        }
      }

      for (let i = 0; i < files.length; i++) {
        request.store.template[files[i].split('.')[0]] = `store.custom.${template}.${files[i].split('.')[0]}`
      }
    } else {
      const template = request.store.env.template.toLowerCase()
      for (let i = 0; i < files.length; i++) {
        request.store.template[files[i].split('.')[0]] = `store.${template}.${files[i].split('.')[0]}`
      }
    }

    await next()
  }
}

module.exports = StoreTemplate
