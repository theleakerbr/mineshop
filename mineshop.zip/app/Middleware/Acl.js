'use strict'

const User = use('App/Models/User')
const UserAcl = use('App/Models/UserAcl')

class Acl {
  async handle ({ request, response, view }, next, params) {
    if (request.user.manage_store === null) {
      const message = 'Desculpe, você precisa conectar-se a uma loja antes de poder realizar essa operação.'

      if (request.method() !== 'GET') {
        return response.status(403).send({
          error: { other: message }
        })
      }

      return response.status(403).send(view.render('panel.error', { message: message }))
    }

    let acl = await UserAcl
    .query()
    .setHidden(['id', 'store_id', 'user_id', 'created_at', 'updated_at'])
    .where('user_id', request.user.id)
    .andWhere('store_id', request.user.manage_store)
    .first()

    try {
      acl = acl.toJSON()
    } catch (err) {
      acl = false
    }

    if (params[0] && params[1] && acl && typeof acl[params[0]] !== 'undefined') {
      if (acl.owner === 1) {
        return await next()
      }

      const level = parseInt(params[1])

      if (typeof level === 'number') {
        if (acl[params[0]] >= level) {
          await next()
        } else {
          const message = 'Desculpe, você não tem permissão para realizar essa operação.'

          if (request.method() !== 'GET') {
            return response.status(403).send({
              error: { other: message }
            })
          }

          response.status(403).send(view.render('panel.error', { message: message }))
        }

        return
      }
    }

    const message = 'Desculpe, algo não está certo com as permissões desta página e por questões de segurança ela foi automaticamente bloqueada. Por favor, entre em contato com o suporte.'

    if (request.method() !== 'GET') {
      return response.status(403).send({
        error: { other: message }
      })
    }

    response.status(403).send(view.render('panel.error', { message: message }))
  }
}

module.exports = Acl
