'use strict'

const _ = use('lodash')
const Route = use('Route')
const Env = use('Env')
const numberFormat = use('locutus/php/strings/number_format')

const moment = use('moment')
moment.locale('pt-BR')

const cdn = Env.get('CDN')
const nodeEnv = Env.get('NODE_ENV')
const port = Env.get('PORT')

const assetsUrl = (arg) => {
  if (!_.isString(arg)) {
    return null
  }

  arg = _.trimStart(_.trim(arg), '/')

  if (_.isEqual(nodeEnv, 'production')) {
    return `${cdn}/${arg}`
  }

  return `/${arg}`
}

const route = (name, params, domain) => {
  params = params || {}

  if (_.isString(domain)) {
    domain = _.toLower(_.trim(domain))

    if (_.isEqual(nodeEnv, 'production')) {
      domain = `https://${domain}`
    } else {
      domain = _.replace(domain, '.com.br', '.test')
      domain = `http://${domain}:${port}`
    }
  } else {
    domain = ''
  }

  return `${domain}${Route.url(name, params)}`
}

const year = () => {
  return _(new Date()).value().getFullYear()
}

class EdgeGlobal {
  async handle ({ view }, next) {
    view.share({
      _: _,
      assetsUrl: assetsUrl,
      numberFormat: numberFormat,
      route: route,
      year: year,
      randomInt: _.random,
      environment: nodeEnv,
      moment: moment
    })

    await next()
  }
}

module.exports = EdgeGlobal
