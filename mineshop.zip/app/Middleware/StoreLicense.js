'use strict'

class StoreLicense {
  async handle ({ request, response, view }, next, ignoreLicense) {
    ignoreLicense = ignoreLicense[0] === 'true'

    if (!request.store) {
      return response.status(404).send(
        view.render('error', {
          status: 404,
          message: 'Esse domínio ou subdomínio não está vinculado a nenhuma loja.'
        })
      )
    }

    if (request.store.status === 'PENDING') {
      return response.status(402).send(
        view.render('error', {
          status: 402,
          message: `Loja pendente! Se você é o(a) responsável por essa loja, \
            clique <a href="https://app.mineshop.com.br" target="_blank">aqui</a> para \
            normalizar essa situação.`.replace(/\s+/g, ' ')
        })
      )
    }

    if (request.store.status === 'SUSPENDED' && !ignoreLicense) {
      return response.status(402).send(
        view.render('error', {
          status: 402,
          message: `Loja suspensa! Se você é o(a) responsável por essa loja, \
            clique <a href="https://app.mineshop.com.br" target="_blank">aqui</a> para \
            normalizar essa situação.`.replace(/\s+/g, ' ')
        })
      )
    }

    await next()
  }
}

module.exports = StoreLicense
