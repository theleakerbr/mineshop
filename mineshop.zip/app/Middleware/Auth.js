'use strict'

const Route = use('Route')

const User = use('App/Models/User')
const UserSession = use('App/Models/UserSession')

class Auth {
  async handle ({ request, response, view, session }, next, inverse) {
    inverse = inverse[0] === 'inverse'
    let user = false
    const token = session.get('userSessionToken', false)

    if (token) {
      let userSession = await UserSession
      .query()
      .where('token', token)
      .andWhere('active', true)
      .first()

      try {
        userSession = userSession.toJSON()
      } catch (err) {
        userSession = false
      }

      if (userSession) {
        user = userSession.user_id
      } else {
        session.forget('userSessionToken')
      }
    }

    if (user) {
      user = await User
      .query()
      .setHidden(['password', 'tfa', 'referral', 'remote_addr', 'user_agent'])
      .where('id', user)
      .first()

      try {
        user = user.toJSON()
      } catch (err) {
        user = false
      }

      if (user && user.group === 'BANNED') {
        user = false
        session.forget('userSessionToken')
      }
    }

    if (!inverse && !user) {
      if (request.method() !== 'GET') {
        return response.status(401).send()
      } else {
        return response.redirect(Route.url('panel.login.show') + '?r=' + request.url())
      }
    }

    if (inverse && user) {
      return response.redirect(Route.url('panel.dashboard.show'))
    }

    request.user = user
    view.share({ user: user })

    await next()
  }
}

module.exports = Auth
