'use strict'

const Store = use('App/Models/Store')
const StoreSetting = use('App/Models/StoreSetting')

class StoreIdentifier {
  async handle ({ request, subdomains }, next) {
    let store = await Store
    .query()
    .setVisible(['id', 'address', 'plan', 'status'])
    .where('address', subdomains.address)
    .first()

    store = store ? store.toJSON() : false

    if (store) {
      let settings = await StoreSetting
      .query()
      .setHidden(['id', 'store_id', 'created_at', 'updated_at'])
      .where('store_id', store.id)
      .first()

      settings = settings ? settings.toJSON() : {}

      for (let setting in settings) {
        try {
          settings[setting] = JSON.parse(settings[setting])
        } catch (err) {}
      }

      store.env = settings
    }

    request.store = store

    await next()
  }
}

module.exports = StoreIdentifier
