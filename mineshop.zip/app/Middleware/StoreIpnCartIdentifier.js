'use strict'

const _ = use('lodash')

const StoreCart = use('App/Models/StoreCart')
const StorePaymentGateway = use('App/Models/StorePaymentGateway')

class StoreIpnCartIdentifier {
  async handle ({ request, response, params }, next) {
    const { ipnToken } = params

    let cart = await StoreCart
    .query()
    .where('ipn_token', ipnToken)
    .first()

    if (!cart) {
      return response.status(422).send({
        message: 'ipn token not recognized'
      })
    }

    cart = _.isFunction(cart.toJSON)
    ? cart.toJSON()
    : cart

    let gateways = await StorePaymentGateway
    .query()
    .where('store_id', cart.store_id)
    .first()

    gateways = _.isFunction(gateways.toJSON)
    ? gateways.toJSON()
    : gateways

    request.cart = cart
    request.gateways = gateways

    await next()
  }
}

module.exports = StoreIpnCartIdentifier
