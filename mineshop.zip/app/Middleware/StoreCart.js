'use strict'

const StoreCartModel = use('App/Models/StoreCart')
const StoreCartItem = use('App/Models/StoreCartItem')
const StoreServer = use('App/Models/StoreServer')
const StoreProduct = use('App/Models/StoreProduct')

class StoreCart {
  async handle ({ request, session }, next) {
    let cartId = session.get('cartId', false)
    let cart = null

    if (cartId) {
      cart = await StoreCartModel.find(cartId)
      if (cart) {
        cart = cart.toJSON()
        if (cart.store_id !== request.store.id || cart.status !== 'OPENED') {
          cart = null
        }
      }
    }

    if (!cart) {
      cart = await StoreCartModel.create({
        store_id: request.store.id,
        nickname: null,
        email: null,
        crafatar_uuid: null,
        coupon_code: null,
        coupon_discount: null,
        subtotal: null,
        total: null,
        payment_method: null,
        status: 'OPENED',
        dispatched: false,
        ipn_token: null,
        remote_addr: request.ip(),
        user_agent: request.header('User-Agent'),
        context: null
      })

      cart = cart.toJSON()
    }

    let items = await StoreCartItem
    .query()
    .setVisible(['store_product_id', 'quantity'])
    .where('store_cart_id', cart.id)
    .orderBy('created_at', 'asc')
    .fetch()

    items = items.toJSON()

    let subtotal = 0
    let total = 0
    let obtainedDiscount = 0
    let quantityItems = 0

    for (let i = 0; i < items.length; i++) {
      const item = items[i]

      let product = await StoreProduct.find(item.store_product_id)
      product = product.toJSON()

      item.name = product.name
      item.price = product.price

      let server = await StoreServer.find(product.store_server_id)
      server = server.toJSON()

      item.server_name = server.name

      quantityItems += item.quantity
      subtotal = subtotal + (item.quantity * item.price)
    }

    if (cart.coupon_discount) {
      obtainedDiscount = subtotal * (cart.coupon_discount / 100)
    }

    total = subtotal - obtainedDiscount

    cart.subtotal = subtotal
    cart.total = total
    cart.obtained_discount = obtainedDiscount
    cart.quantity_items = quantityItems
    cart.items = items

    delete cart.store_id
    delete cart.payment_method
    delete cart.status
    delete cart.ipn_token
    delete cart.remote_addr
    delete cart.user_agent
    delete cart.context
    delete cart.needs_revision
    delete cart.created_at
    delete cart.updated_at

    session.put('cartId', cart.id)
    request.store.cart = cart

    await next()
  }
}

module.exports = StoreCart
