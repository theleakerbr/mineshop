'use strict'

const User = use('App/Models/User')
const UserAcl = use('App/Models/UserAcl')
const Store = use('App/Models/Store')
const StoreSetting = use('App/Models/StoreSetting')

class ManageStore {
  async handle ({ request, view }, next) {
    if (request.user.manage_store === null) {
      return await next()
    }

    let acl = await UserAcl
    .query()
    .where('user_id', request.user.id)
    .andWhere('store_id', request.user.manage_store)
    .first()

    try {
      acl = acl.toJSON()
    } catch (err) {
      acl = false
    }

    if (!acl) {
      request.user.manage_store = null

      const user = await User.find(request.user.id)
      user.merge({ manage_store: null })

      return await user.save()
    }

    const storeSettings = await StoreSetting
    .query()
    .where('store_id', request.user.manage_store)
    .first()

    const store = await Store.find(request.user.manage_store)

    view.share({
      storeId: request.user.manage_store,
      storeAddress: store.address,
      storeName: storeSettings.name,
      storeDaysRemaining: store.days_remaining,
      storeStatus: store.status
    })

    await next()
  }
}

module.exports = ManageStore
