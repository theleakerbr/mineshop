'use strict'

const moment = use('moment')

const StoreServer = use('App/Models/StoreServer')

class ServerAuth {
  async handle ({ request, response }, next) {
    const token = request.header('Authorization', false)

    if (!token) {
      return response.status(401).send()
    }

    let server = await StoreServer
    .query()
    .where('token', token)
    .first()

    if (!server) {
      return response.status(401).send()
    }

    server.merge({
      last_connection: moment().format('YYYY-MM-DD HH:mm:ss')
    })

    await server.save()

    try {
      server = server.toJSON()
    } catch (err) {}

    request.server = server

    await next()
  }
}

module.exports = ServerAuth
