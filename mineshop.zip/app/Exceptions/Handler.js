'use strict'

const BaseExceptionHandler = use('BaseExceptionHandler')
const Env = use('Env')
const Logger = use('Logger')

const nodeEnv = Env.get('NODE_ENV')

class ExceptionHandler extends BaseExceptionHandler {
  async handle (error, { request, response, view }) {
    let message = 'Desculpe, algo não saiu como esperado. Por favor, tente novamente!'

    if (nodeEnv.toLowerCase() === 'development') {
      message = error.message
    }

    if (error.status >= 400 && error.status <= 499) {
      if (error.status === 404) {
        message = 'Desculpe, não conseguimos encontrar a página que você está procurando.'
      } else {
        if (error.status === 403 && error.message.indexOf('EBADCSRFTOKEN') > -1) {
          message = 'Desculpe, por questões de segurança precisamos que você atualize a página e tente novamente.'
        } else {
          message = error.message
        }
      }
    } else {
      if (error.message.toLowerCase().indexOf('template') !== -1) {
        message = error.message
      }
    }

    if (request.method() !== 'GET') {
      return response.status(error.status).send({ error: { other: message } })
    }

    response.status(error.status).send(view.render('error', {
      status: error.status,
      message: message
    }))
  }

  async report (error, { request }) {
    let message = `${request.method()} ${request.header('Host')}${request.originalUrl()}`

    if (error.status >= 400 && error.status <= 499) {
      if (error.status === 404) {
        Logger.notice(`Route not found ${message}`)
      } else {
        Logger.notice(`${error.message} ${message}`)
        Logger.notice(error.stack)
      }
    } else {
      if (error.sql) {
        message += `${error.code} ${error.sqlMessage} ${message}`
      } else {
        message += `${error.name} (...${error.stack.split('\n')[1].substr(-30)}:${error.column}) ${message}`
      }

      Logger.error(message)
      Logger.error(error.stack)
    }
  }
}

module.exports = ExceptionHandler
