'use strict'

const Model = use('Model')

class UserRecovery extends Model {
}

module.exports = UserRecovery
