'use strict'

const Model = use('Model')

class Statistic extends Model {
  static get primaryKey () {
    return 'key'
  }
}

module.exports = Statistic
