'use strict'

const Model = use('Model')
const Encryption = use('Encryption')
const _ = use('lodash')

class StorePaymentGateway extends Model {
  getPaypal (value) {
    return JSON.parse(Encryption.decrypt(value))
  }

  setPaypal (value) {
    if ((!_.isString(value) && !_.isNull(value)) || _.isNull(value)) {
      return null
    }

    value = JSON.parse(value)

    const basic = {
      clientId: _.has(value, 'basic.clientId')
      ? _.trim(value.basic.clientId)
      : '',

      clientSecret: _.has(value, 'basic.clientSecret')
      ? _.trim(value.basic.clientSecret)
      : '',

      active: _.has(value, 'basic.active') && _.isBoolean(value.basic.active)
      ? value.basic.active
      : false
    }

    return Encryption.encrypt(JSON.stringify({
      basic: basic
    }))
  }

  getMercadopago (value) {
    return JSON.parse(Encryption.decrypt(value))
  }

  setMercadopago (value) {
    if ((!_.isString(value) && !_.isNull(value)) || _.isNull(value)) {
      return null
    }

    value = JSON.parse(value)

    const basic = {
      clientId: _.has(value, 'basic.clientId')
      ? _.trim(value.basic.clientId)
      : '',

      clientSecret: _.has(value, 'basic.clientSecret')
      ? _.trim(value.basic.clientSecret)
      : '',

      active: _.has(value, 'basic.active') && _.isBoolean(value.basic.active)
      ? value.basic.active
      : false
    }

    return Encryption.encrypt(JSON.stringify({
      basic: basic
    }))
  }

  getPagseguro (value) {
    return JSON.parse(Encryption.decrypt(value))
  }

  setPagseguro (value) {
    if ((!_.isString(value) && !_.isNull(value)) || _.isNull(value)) {
      return null
    }

    value = JSON.parse(value)

    const basic = {
      email: _.has(value, 'basic.email')
      ? _.trim(value.basic.email)
      : '',

      token: _.has(value, 'basic.token')
      ? _.trim(value.basic.token)
      : '',

      active: _.has(value, 'basic.active') && _.isBoolean(value.basic.active)
      ? value.basic.active
      : false
    }

    return Encryption.encrypt(JSON.stringify({
      basic: basic
    }))
  }
}

module.exports = StorePaymentGateway
