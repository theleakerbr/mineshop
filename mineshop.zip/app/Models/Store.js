'use strict'

const Model = use('Model')

class Store extends Model {
}

module.exports = Store
