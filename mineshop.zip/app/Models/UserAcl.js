'use strict'

const Model = use('Model')

class UserAcl extends Model {
}

module.exports = UserAcl
