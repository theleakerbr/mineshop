'use strict'

const Model = use('Model')

class StoreCart extends Model {
}

module.exports = StoreCart
