'use strict'

const Model = use('Model')

class UserFeedback extends Model {
}

module.exports = UserFeedback
