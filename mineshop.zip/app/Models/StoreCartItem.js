'use strict'

const Model = use('Model')

class StoreCartItem extends Model {
}

module.exports = StoreCartItem
