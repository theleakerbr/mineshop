'use strict'

const Model = use('Model')

class StoreDiscountCoupon extends Model {
}

module.exports = StoreDiscountCoupon
