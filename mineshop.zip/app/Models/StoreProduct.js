'use strict'

const Model = use('Model')

class StoreProduct extends Model {
}

module.exports = StoreProduct
