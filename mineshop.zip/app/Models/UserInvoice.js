'use strict'

const Model = use('Model')

class UserInvoice extends Model {
}

module.exports = UserInvoice
