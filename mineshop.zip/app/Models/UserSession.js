'use strict'

const Model = use('Model')

class UserSession extends Model {
}

module.exports = UserSession
