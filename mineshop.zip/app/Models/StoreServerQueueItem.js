'use strict'

const Model = use('Model')

class StoreServerQueueItem extends Model {
}

module.exports = StoreServerQueueItem
