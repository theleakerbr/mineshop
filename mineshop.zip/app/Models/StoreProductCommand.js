'use strict'

const Model = use('Model')

class StoreProductCommand extends Model {
}

module.exports = StoreProductCommand
