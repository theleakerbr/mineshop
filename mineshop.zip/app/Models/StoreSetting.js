'use strict'

const Model = use('Model')

class StoreSetting extends Model {
}

module.exports = StoreSetting
