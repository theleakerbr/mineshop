'use strict'

const Model = use('Model')

class StoreLog extends Model {
}

module.exports = StoreLog
