'use strict'

const Model = use('Model')

class StoreServer extends Model {
}

module.exports = StoreServer
