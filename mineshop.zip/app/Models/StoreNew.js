'use strict'

const Model = use('Model')

class StoreNew extends Model {
}

module.exports = StoreNew
